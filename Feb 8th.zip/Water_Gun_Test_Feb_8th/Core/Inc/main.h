/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <tuss4470.h>
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void TUSS4470_StartPWMBurst(uint32_t freq, uint32_t pulses);
void TUSS4470_StartPWMBurst_175kHz(uint32_t pulses);
void StartBurst(uint32_t pulses);
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BUZZER_OUT_Pin GPIO_PIN_2
#define BUZZER_OUT_GPIO_Port GPIOE
#define VIBRATOR_OUT_Pin GPIO_PIN_3
#define VIBRATOR_OUT_GPIO_Port GPIOE
#define TUSS_OUT3_Pin GPIO_PIN_6
#define TUSS_OUT3_GPIO_Port GPIOE
#define LED_CONTROL_OUT_Pin GPIO_PIN_0
#define LED_CONTROL_OUT_GPIO_Port GPIOA
#define TUSS_NCS_Pin GPIO_PIN_4
#define TUSS_NCS_GPIO_Port GPIOA
#define TUSS_OUT4_Pin GPIO_PIN_7
#define TUSS_OUT4_GPIO_Port GPIOE
#define TUSS_OUT4_EXTI_IRQn EXTI9_5_IRQn
#define TUSS_IO1_Pin GPIO_PIN_11
#define TUSS_IO1_GPIO_Port GPIOE
#define BLUE_LED_OUT_Pin GPIO_PIN_9
#define BLUE_LED_OUT_GPIO_Port GPIOD
#define GREEN_LED_OUT_Pin GPIO_PIN_10
#define GREEN_LED_OUT_GPIO_Port GPIOD
#define RED_LED_OUT_Pin GPIO_PIN_11
#define RED_LED_OUT_GPIO_Port GPIOD
#define TRIGGER_IN_Pin GPIO_PIN_0
#define TRIGGER_IN_GPIO_Port GPIOD
#define COMM_IN_Pin GPIO_PIN_1
#define COMM_IN_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */



/* USER CODE BEGIN Private defines */


/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
