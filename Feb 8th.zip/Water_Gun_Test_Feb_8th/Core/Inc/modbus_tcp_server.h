/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : tcp_serevr.h
  * Description        : This file provides code for the configuration
  *                      of the tcp_server of modbus communication.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 FOX SOLUTIONS.
  * All rights reserved.
  *
  *
  *************************************************************************

  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __mx_tcp_server_H
#define __mx_tcp_server_H
#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "inttypes.h"

/* Includes for RTOS ---------------------------------------------------------*/
#if WITH_RTOS
#include "lwip/tcpip.h"
#endif /* WITH_RTOS */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* Global Variables ----------------------------------------------------------*/
 /* structure for maintaining connection infos to be passed as argument
//    to LwIP callbacks*/
// struct modbus_tcp_struct
// {
//   u8_t state;             /* current connection state */
//   u8_t retries;
//   struct tcp_pcb *pcb;    /* pointer on the current tcp_pcb */
//   struct pbuf *p;         /* pointer on the received/to be transmitted pbuf */
// };

/* MODBUS server init function */
//void modbus_server_init(void);
void modbus_tcp_init(void);
#if !WITH_RTOS
/* USER CODE BEGIN 1 */
/* Function defined in lwip.c to:
 *   - Read a received packet from the Ethernet buffers
 *   - Send it to the lwIP stack for handling
 *   - Handle timeouts if NO_SYS_NO_TIMERS not set
 */
//void modbus_process(void);
//err_t modbus_tcp_accept(void *arg, struct tcp_pcb *newpcb, err_t err);
//err_t modbus_tcp_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err);
//void modbus_tcp_error(void *arg, err_t err);
//err_t modbus_tcp_poll(void *arg, struct tcp_pcb *tpcb);
//err_t modbus_tcp_sent(void *arg, struct tcp_pcb *tpcb, u16_t len);
//void modbus_tcp_send(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
//void modbus_tcp_connection_close(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);


/* USER CODE END 1 */
#endif /* WITH_RTOS */

#ifdef __cplusplus
}
#endif
#endif /*__ mx_lwip_H */

/**
  * @}
  */

/**
  * @}
  */



