//#ifndef TUSS4470_H
//#define TUSS4470_H
//
//#include "stm32h7xx_hal.h"
//#include <stdint.h>
//#include <stdbool.h>
//#include <string.h>
//#include <stdio.h>
//#include <main.h>
//
//// TUSS4470 Register Addresses
//#define BPF_CONFIG_1      0x10
//#define BPF_CONFIG_2      0x11
//#define DEV_CTRL_1        0x12
//#define DEV_CTRL_2        0x13
//#define DEV_CTRL_3        0x14
//#define VDRV_CTRL         0x16
//#define ECHO_INT_CONFIG   0x17
//#define ZC_CONFIG         0x18
//#define BURST_PULSE       0x1A
//#define TOF_CONFIG        0x1B
//#define DEV_STAT          0x1C
//#define DEVICE_ID         0x1D
//#define REV_ID            0x1E
//
//// GPIO Definitions from main.h
//#define TUSS_CS_PIN       TUSS_NCS_Pin
//#define TUSS_CS_PORT      TUSS_NCS_GPIO_Port
//#define TUSS_IO1_PIN      TUSS_IO1_Pin
//#define TUSS_IO1_PORT     TUSS_IO1_GPIO_Port
//#define TUSS_IO2_PIN      TUSS_IO2_Pin
//#define TUSS_IO2_PORT     TUSS_IO2_GPIO_Port
//
////// External peripherals
//#define RED_LED_PIN       RED_LED_OUT_Pin
//#define RED_LED_PORT      RED_LED_OUT_GPIO_Port
//#define GREEN_LED_PIN     GREEN_LED_OUT_Pin
//#define GREEN_LED_PORT    GREEN_LED_OUT_GPIO_Port
//#define BLUE_LED_PIN      BLUE_LED_OUT_Pin
//#define BLUE_LED_PORT     BLUE_LED_OUT_GPIO_Port
//
//// Configuration
//#define BURST_INTERVAL    250  // ms
//#define PULSE_FREQUENCY   120  // 120 kHz
//
//// SPI Handle
//extern SPI_HandleTypeDef hspi1;
//
//// UART Handle for communication
//extern UART_HandleTypeDef huart1;
//
//// Command buffer size
//#define CMD_BUFFER_SIZE   64
//#define MAX_PARAMS        5
//extern char cmd_buffer[CMD_BUFFER_SIZE];
//// Global variables (extern for main.c access)
//extern int rawADCValues[300];
//extern int adcSampleCount;
//extern bool continuousBurstEnabled;
//extern unsigned long lastBurstTime;
//
//// Command structure
//typedef struct {
//    char command[20];
//    uint8_t num_params;
//    uint32_t params[MAX_PARAMS];
//} Command_t;
//
//// Function Prototypes
//void TUSS4470_Init(void);
//void TUSS4470_WriteRegister(uint8_t regAddr, uint8_t data);
//uint8_t TUSS4470_ReadRegister(uint8_t regAddr);
//void TUSS4470_Generate120kHzClockPulses(int numPulses);
//void TUSS4470_TriggerBurst_IO_MODE1(void);
//void TUSS4470_DelayUS(uint32_t microseconds);
//uint16_t TUSS4470_CalculateParity(uint16_t data);
//void TUSS4470_UART_Send(const char* format, ...);
//void TUSS4470_ProcessCommand(Command_t* cmd);
//void TUSS4470_ParseCommand(char* cmd_str, Command_t* cmd);
//void TUSS4470_ConfigureTUSS4470(void);
//void TUSS4470_ReadDeviceStatus(void);
//void TUSS4470_VerifyConfiguration(void);
//void TUSS4470_PerformMeasurement(void);
//void TUSS4470_MonitorVOUTSignal(void);
//float TUSS4470_CaptureEcho(void);
//void TUSS4470_GenerateBurst(int numPulses);
//void TUSS4470_ContinuousMode(void);
//void TUSS4470_PrintHelp(void);
//
//#endif /* TUSS4470_H */
#ifndef TUSS4470_H
#define TUSS4470_H

#include "stm32h7xx_hal.h"
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <main.h>

// TUSS4470 Register Addresses
#define BPF_CONFIG_1      0x10
#define BPF_CONFIG_2      0x11
#define DEV_CTRL_1        0x12
#define DEV_CTRL_2        0x13
#define DEV_CTRL_3        0x14
#define VDRV_CTRL         0x16
#define ECHO_INT_CONFIG   0x17
#define ZC_CONFIG         0x18
#define BURST_PULSE       0x1A
#define TOF_CONFIG        0x1B
#define DEV_STAT          0x1C
#define DEVICE_ID         0x1D
#define REV_ID            0x1E

// GPIO Definitions from main.h
#define TUSS_CS_PIN       TUSS_NCS_Pin
#define TUSS_CS_PORT      TUSS_NCS_GPIO_Port
#define TUSS_IO1_PIN      TUSS_IO1_Pin
#define TUSS_IO1_PORT     TUSS_IO1_GPIO_Port
//#define TUSS_IO2_PIN      TUSS_IO2_Pin
//#define TUSS_IO2_PORT     TUSS_IO2_GPIO_Port

//// External peripherals
#define RED_LED_PIN       RED_LED_OUT_Pin
#define RED_LED_PORT      RED_LED_OUT_GPIO_Port
#define GREEN_LED_PIN     GREEN_LED_OUT_Pin
#define GREEN_LED_PORT    GREEN_LED_OUT_GPIO_Port
#define BLUE_LED_PIN      BLUE_LED_OUT_Pin
#define BLUE_LED_PORT     BLUE_LED_OUT_GPIO_Port

// Configuration
#define BURST_INTERVAL     5000
#define PULSE_FREQUENCY   175  // 175 kHz

// SPI Handle
extern SPI_HandleTypeDef hspi1;

// UART Handle for communication
extern UART_HandleTypeDef huart1;

// Command buffer size
#define CMD_BUFFER_SIZE   64
#define MAX_PARAMS        15
extern char cmd_buffer[CMD_BUFFER_SIZE];
// Global variables (extern for main.c access)
extern int rawADCValues[300];
extern int adcSampleCount;
extern bool continuousBurstEnabled;
extern unsigned long lastBurstTime;
/* ===== TOF shared variables (defined in main.c) ===== */
extern volatile uint32_t tof_start_us;
extern volatile uint32_t tof_stop_us;
extern volatile uint8_t  echo_received;

/* ===== timing helper ===== */
uint32_t micros(void);
// Command structure
typedef struct {
    char command[20];
    uint8_t num_params;
    uint32_t params[MAX_PARAMS];
} Command_t;

// Function Prototypes
extern void StartBurst(uint32_t pulses);
void TUSS4470_Init(void);
void TUSS4470_WriteRegister(uint8_t regAddr, uint8_t data);
uint8_t TUSS4470_ReadRegister(uint8_t regAddr);
void TUSS4470_Generate120kHzClockPulses(int numPulses);
void TUSS4470_TriggerBurst_IO_MODE1(void);
void TUSS4470_DelayUS(uint32_t microseconds);
uint16_t TUSS4470_CalculateParity(uint16_t data);
void TUSS4470_UART_Send(const char* format, ...);
void TUSS4470_ProcessCommand(Command_t* cmd);
void TUSS4470_ParseCommand(char* cmd_str, Command_t* cmd);
void TUSS4470_ConfigureTUSS4470(void);
void TUSS4470_ReadDeviceStatus(void);
void TUSS4470_VerifyConfiguration(void);
void TUSS4470_PerformMeasurement(void);
void TUSS4470_MonitorVOUTSignal(void);
float TUSS4470_CaptureEcho(void);
void TUSS4470_GenerateBurst(int numPulses);
void TUSS4470_ContinuousMode(void);
void TUSS4470_PrintHelp(void);
float TUSS4470_MeasureDistance_cm(void);
void TUSS4470_IO1_Set(bool state) ;



#endif /* TUSS4470_H */
