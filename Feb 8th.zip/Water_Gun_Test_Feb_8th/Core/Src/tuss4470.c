#include "tuss4470.h"
#include <stdarg.h>
#include <ctype.h>
#include <string.h>
#include <math.h>
#include<stdlib.h>
#include <main.h>
// Global variables matching ESP32 code
char uart_buffer[256];
char cmd_buffer[CMD_BUFFER_SIZE];
uint16_t cmd_index = 0;
extern uint8_t do_read1;
bool continuousBurstEnabled = false;
unsigned long lastBurstTime = 0;

// Burst control variables from TI reference (matching ESP32 code)
uint8_t IO2_toggleCount = 0;
bool timerBurstDone = false;
uint8_t numberOfHalfPulses = 0;

// UART send function with variable arguments (matching ESP32 output format)
void TUSS4470_UART_Send(const char* format, ...) {
    va_list args;
    va_start(args, format);
    int len = vsnprintf(uart_buffer, sizeof(uart_buffer), format, args);
    va_end(args);

    if (len > 0) {
        HAL_UART_Transmit(&huart1, (uint8_t*)uart_buffer, len, HAL_MAX_DELAY);
    }
}

// Chip Select control
static void TUSS4470_CS_Low(void) {
    HAL_GPIO_WritePin(TUSS_CS_PORT, TUSS_CS_PIN, GPIO_PIN_RESET);
}

static void TUSS4470_CS_High(void) {
    HAL_GPIO_WritePin(TUSS_CS_PORT, TUSS_CS_PIN, GPIO_PIN_SET);
}

// IO Control (matching ESP32 code)
 void TUSS4470_IO1_Set(bool state) {
    HAL_GPIO_WritePin(TUSS_IO1_PORT, TUSS_IO1_PIN, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

//static void TUSS4470_IO2_Set(bool state) {
//    HAL_GPIO_WritePin(TUSS_IO2_PORT, TUSS_IO2_PIN, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
//}

// LED Control (for status indication)
static void TUSS4470_LED_Set(uint8_t color, bool state) {
    switch(color) {
        case 'R': // Red
          //  HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
            break;
        case 'G': // Green
          //  HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
            break;
        case 'B': // Blue
          //  HAL_GPIO_WritePin(BLUE_LED_PORT, BLUE_LED_PIN, state ? GPIO_PIN_SET : GPIO_PIN_RESET);
            break;
        default:
            break;
    }
}

// Delay function with DWT (for accurate μs delays)
void TUSS4470_DelayUS(uint32_t microseconds) {
    static uint8_t dwt_initialized = 0;

    if(!dwt_initialized) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
        dwt_initialized = 1;
    }

    uint32_t startTick = DWT->CYCCNT;
    uint32_t clockMhz = HAL_RCC_GetHCLKFreq() / 1000000;
    uint32_t delayTicks = microseconds * clockMhz;

    while((DWT->CYCCNT - startTick) < delayTicks);
}


/*
// TI Reference parity calculation (EXACTLY as in ESP32 code)
uint16_t TUSS4470_CalculateParity(uint16_t data) {
    uint8_t count = 0;
    for (int i = 0; i < 16; i++) {
        if (data & (1 << i)) count++;
    }
    return (count % 2 == 0) ? (data | (1 << 8)) : data;
}*/

uint16_t TUSS4470_CalculateParity(uint16_t data) {
    uint8_t count = 0;
    for (int i = 0; i < 16; i++) {
        if (data & (1 << i)) count++;
    }
    // Even parity: set bit 8 only if count is ODD (to make total EVEN)
    return (count % 2 != 0) ? (data | (1 << 8)) : data;
}



// Write to TUSS4470 register (EXACTLY as in ESP32 code)
void TUSS4470_WriteRegister(uint8_t address, uint8_t data) {
    uint16_t frame = ((0 << 15) | ((address & 0x3F) << 9) | data);
    frame = TUSS4470_CalculateParity(frame);

    TUSS4470_CS_Low();
    HAL_SPI_Transmit(&hspi1, (uint8_t*)&frame, 1, 100);
    TUSS4470_CS_High();
    TUSS4470_DelayUS(10);
}

// Read from TUSS4470 register (EXACTLY as in ESP32 code)
uint8_t TUSS4470_ReadRegister(uint8_t address) {
    uint16_t frame = ((1 << 15) | ((address & 0x3F) << 9));
    frame = TUSS4470_CalculateParity(frame);

    TUSS4470_CS_Low();
    uint16_t response;
    HAL_SPI_TransmitReceive(&hspi1, (uint8_t*)&frame, (uint8_t*)&response, 1, 100);
    TUSS4470_CS_High();

    TUSS4470_DelayUS(10);
    return response & 0xFF;
}

// =============================================================================
// REGISTER CONFIGURATION - EXACTLY MATCHING ESP32 CODE
// =============================================================================
void TUSS4470_ConfigureTUSS4470(void) {
    TUSS4470_UART_Send("\r\n");
    TUSS4470_UART_Send("=== CONFIGURING TUSS4470 (TI REFERENCE CORRECTED) ===\r\n");

    // Read current device ID to verify communication
    uint8_t device_id = TUSS4470_ReadRegister(DEVICE_ID);
    TUSS4470_UART_Send("Device ID: 0x%02X\r\n", device_id);

    if (device_id != 0xB9) {
        TUSS4470_UART_Send("❌ DEVICE COMMUNICATION FAILED - Check SPI connections\r\n");
        TUSS4470_LED_Set('R', 1); // Red LED for error
        return;
    }

    TUSS4470_LED_Set('G', 1); // Green LED for success

// below are the TUSS Configurations

/* To change burst Frequency, change these parameters:  sConfigOC.Pulse = 350 (line 1027); //240 = 175KHz, 350 = 120KHz and
    htim1.Init.Period = 699 (line 1002);   //479 = 175KHz , 699 = 120KHz   at the main.c */

     TUSS4470_WriteRegister(BPF_CONFIG_1, 0x1B); // was 0x1B for (177KHz) , 0x14 => 121.33KHz, 0x70 HPF
   // TUSS4470_WriteRegister(BPF_CONFIG_1, 0x30);  //BPF TRIM ENABLE
     HAL_Delay(10);
//     BPF1 FREQ (KHZ)
//     0x00 40.64
//     0x01 44.05
//     0x02 45.6
//     0x03 48.86
//     0x04 50.58
//     0x05 52.96
//     0x06 56.75
//     0x07 60.11
//     0x08 62.95
//     0x09 66.68
//     0x0A 71.44
//     0x0B 74.81
//     0x0C 79.24
//     0x0D 82.03
//     0x0E 86.89
//     0x0F 92.04
//     0x10 97.49
//     0x11 103.27
//     0x12 109.4
//     0x13 114.54
//     0x14 121.33
//     0x15 128.52
//	 0x16 134.58
//	 0x17 142.55
//	 0x18 151.01
//	 0x19 159.94
//	 0x1A 167.48
//	 0x1B 177.41
//	 0x1C 185.77
//	 0x1D 196.78
//	 0x1E 206.05
//	 0x1F 218.26
//	 0x20 228.54
//	 0x21 244.89
//	 0x22 256.43
//	 0x23 271.63
//	 0x24 284.43
//	 0x25 301.28
//	 0x26 319.13
//	 0x27 338.14
//	 0x28 353.97
//	 0x29 374.95
//	 0x2A 397.16
//	 0x2B 408.17
//	 0x2C 420.7
//	 0x2D 455.63
//	 0x2E 472.03
//	 0x2F 500



       TUSS4470_WriteRegister(BPF_CONFIG_2, 0x00); // BPF Q=4
     //TUSS4470_WriteRegister(BPF_CONFIG_2, 0x00); // BPF Q=8
       HAL_Delay(10);
//       Bit Field Type Reset Description
//       7:6 RESERVED R 0x0 Reserved
//       5:4 BPF_Q_SEL R/W 0x0 Bandpass filter Q factor. Valid only when BPF_BYPASS = 0
//       0x0 = 4
//       0x1 = 5
//       0x2 = 2
//       0x3 = 3
//       3:0 BPF_FC_TRIM R/W 0x0 Offset BPF_HPF_FREQ when BPF_FC_TRIM_FRC = 1:
//       BPF_HPF_FREQ = BPF_HPF_FREQ + BPF_FC_TRIM
//       See "Bandpass filter center frequency range extension" table

       TUSS4470_WriteRegister(DEV_CTRL_1, 0x00); // 0x0B max gain. 0xC7 Logamp default
       HAL_Delay(10);
//       Bit Field Type Reset Description
//       7 LOGAMP_FRC R/W 0x0 Override for factory settings for LOGAMP_SLOPE_ADJ and
//       LOGAMP_INT_ADJ
//       6:4 LOGAMP_SLOPE_ADJ R/W 0x0 Slope or gain adjustment at the final output on VOUT pin. Slope
//       adjustment depends on the setting of VOUT_SCALE_SEL.
//       0x0 = 3.0× VOUT_SCALE_SEL+4.56×VOUT_SCALE_SEL V/V
//       0x1 = 3.1× VOUT_SCALE_SEL+4.71×VOUT_SCALE_SEL V/V
//       0x2 = 3.2× VOUT_SCALE_SEL+4.86×VOUT_SCALE_SEL V/V
//       0x3 = 3.3× VOUT_SCALE_SEL+5.01×VOUT_SCALE_SEL V/V
//       0x4 = 2.6× VOUT_SCALE_SEL+3.94×VOUT_SCALE_SEL V/V
//       0x5 = 2.7× VOUT_SCALE_SEL+ 4.10×VOUT_SCALE_SEL V/V
//       0x6 = 2.8× VOUT_SCALE_SEL+4.25×VOUT_SCALE_SEL V/V
//       0x7 = 2.9× VOUT_SCALE_SEL+4.4×VOUT_SCALE_SEL V/V
//       3:0 LOGAMP_INT_ADJ R/W 0x0 Logamp Intercept adjustment. See "Logamp intercept adjustment"
//       table in specification for values.

       TUSS4470_WriteRegister(DEV_CTRL_2, 0x00); // 0x00 = 3.3V mode, LNA=15V/V
       HAL_Delay(10);
//       Bit Field Type Reset Description
//       7 LOGAMP_DIS_FIRST R/W 0x0 Disable first logamp stage to reduce quiescent current
//       6 LOGAMP_DIS_LAST R/W 0x0 Disable last logamp stage quiescent current
//       3 RESERVED R 0x0 Reserved
//       2 VOUT_SCALE_SEL R/W 0x0 Select VOUT scaling
//       0x0 = Select Vout gain to map output to 3.3 V
//       0x1 = Select Vout gain to map output to 5.0 V
//       1:0 LNA_GAIN R/W 0x0 Adjust LNA Gain in V/V
//       0x0 = 15 V/V
//       0x1 = 10 V/V
//       0x2 = 20 V/V
//       0x3 = 12.5 V/V


       //TUSS4470_WriteRegister(DEV_CTRL_3, 0x08 | 0x01); // {0x08 | 0x01 DRV_PLS_FLT_DT=2 (32μs) - IOMODE=1}
       TUSS4470_WriteRegister(DEV_CTRL_3, 0x01 | 0x01);  // 0x11: 64μs, IO_MODE=1
       HAL_Delay(10);
//       Bit Field Type Reset Description
//       4:2 DRV_PLS_FLT_DT R/W 0x0 Driver Pulse Fault Deglitch Time.
//       In IO_MODE = 0 or IO_MODE = 1, DRV_PULSE_FLT will be set if
//       start of burst is triggered and IO2 pin has not toggled for greater than
//       deglitch Time.
//       In IO_MODE = 2, DRV_PULSE_FLT will be set if start of burst is
//       triggered and if IO1 or IO2 do not toggle a period longer than the
//       deglitch time except when both pins are high.
//       0x0 = 64 µs
//       0x1 = 48 µs
//       0x2 = 32 µs
//       0x3 = 24 µs
//       0x4 = 16 µs
//       0x5 = 8 µs
//       0x6 = 4 µs
//       0x7 = Check Disabled
//       1:0 IO_MODE R/W 0x0 Configuration for low voltage IO pins.
//       0x0 = IOMODE 0
//       0x1 = IOMODE 1
//       0x2 = IOMODE 2
//       0x3 = IOMODE 3

      // TUSS4470_WriteRegister(VDRV_CTRL, 0x00); //VDRV set to 11 V
       TUSS4470_WriteRegister(VDRV_CTRL, 0x4F); //FOR 11V = 0x02, FOR 15 V =  0X03, FOR 5V, 0x00, 0x4A for 15V, For 0x5F VDRV is 20V, current 20mA
       HAL_Delay(10);
//       Bit Field Type Reset Description
//       7 RESERVED R 0x0 Reserved
//       6 DIS_VDRV_REG_LSTN R/W 0x0 Automatically disable VDRV charging in listen mode every time after
//       burst mode is exited given VDRV_TRIGGER =0x0.
//       0x0 = Do not automatically disable VDRV charging
//       0x1 = Automatically disable VDRV charging
//       5 VDRV_HI_Z R/W 0x1 Turn off current source between VPWR and VRDV and disable
//       VDRV regulation.
//       0x0 = VDRV not Hi-Z
//       0x1 = VDRV in Hi-Z mode
//       4 VDRV_CURRENT_LEVEL R/W 0x0 Pull up current at VDRV pin
//       0x0 = 10 mA
//       0x1 = 20 mA
//       3:0 VDRV_VOLTAGE_LEVEL R/W 0x0 Regulated Voltage at VDRV pin Value is calculated as :
//       VDRV = VDRV_VOLTAGE_LEVEL + 5 [V]

       // Enable echo interrupt with 1.0V threshold
       //TUSS4470_WriteRegister(ECHO_INT_CONFIG, 0x1F); // 0x10 (enable) | 0x0F (1.0V)

       // Echo threshold ~0.3V
       TUSS4470_WriteRegister(ECHO_INT_CONFIG, 0x1F);
       HAL_Delay(10);
//       Bit Field Type Reset Description
//       7:5 RESERVED R 0x0 Reserved
//       4 ECHO_INT_CMP_EN R/W 0x0 Enable echo interrupt comparator output
//	   3:0 ECHO_INT_THR_SEL R/W 0x7 Threshold level to issue interrupt on OUT4 pin. Applied to Low pass
//	   filter output.
//	   If VOUT_SCALE_SEL=0x0 :
//	   Threshold = 0.04 x ECHO_INT_THR_SEL + 0.4 [V]
//	   If VOUT_SCALE_SEL=0x1:
//	   Threshold = 0.06 x ECHO_INT_THR_SEL + 0.6 [V]

       // Enable zero crossing for validation
       // Stage 3, 230mV hysteresis, differential input
 //     TUSS4470_WriteRegister(ZC_CONFIG, 0xB4); // 0x80|0x20|0x10|0x04
       TUSS4470_WriteRegister(ZC_CONFIG, 0x00); // DISABLE ZC
       HAL_Delay(10);
//       7 ZC_CMP_EN R/W 0x0 Enable Zero Cross Comparator for Frequency detection
//       6 ZC_EN_ECHO_INT R/W 0x0 When set, provides ZC information only when object is detected
//       5 ZC_CMP_IN_SEL R/W 0x0 Zero Comparator Input Select
//       0x0 = INP - VCM
//       0x1 = INP - INN
//       4:3 ZC_CMP_STG_SEL R/W 0x2 Zero Cross Comparator Stage Select
//       2:0 ZC_CMP_HYST R/W 0x4 Zero Cross Comparator Hysteresis Selection
//       0x0 = 30 mV
//       0x1 = 80 mV
//       0x2 = 130 mV
//       0x3 = 180 mV
//       0x4 = 230 mV
//       0x5 = 280 mV
//       0x6 = 330 mV
//       0x7 = 380 mV

       TUSS4470_WriteRegister(BURST_PULSE, 0x14);//5 Burst Pulses -- HALF_BRG_MODE = 0, Full Bridge, Case 1
       HAL_Delay(10);
//       Bit Field Type Reset Description
//       7 HALF_BRG_MODE R/W 0x0 Use output driver in half-bridge mode.
//       When enabled, drive both high-side FET together and low-side FETs
//       together.
//       0x0 = Disable half-bridge mode
//       0x1 = Enable half bridge mode
//       6 PRE_DRIVER_MODE R/W 0x0 Pre-driver mode to drive external FETs
//       0x0 = Disable pre-driver mode
//       0x1 = Enable pre-driver mode
//       5:0 BURST_PULSE R/W 0x0 Number of burst

       TUSS4470_WriteRegister(TOF_CONFIG, 0x02);
       HAL_Delay(10);
//       Bit Field Type Reset Description3
//       7 SLEEP_MODE_EN R/W 0x0 For entering or exiting sleep mode
//       0x0 = Wake up or exit Sleep Mode
//       0x1 = Enter sleep mode
//       6 STDBY_MODE_EN R/W 0x0 For entering or exiting standby mode
//       0x0 = Exit Standby Mode
//       0x1 = Enter Standby mode
//       5:2 RESERVED R 0x0 Reserved
//       1 VDRV_TRIGGER R/W 0x0 Control charging of VDRV pin when DIS_VDRV_REG_LSTN = 1.
//       This has no effect when VDRV_HI_Z=0x1.
//       0x0 = Disable IVDRV
//       0x1 = Enable IVDRV
//       0 CMD_TRIGGER R/W 0x0 For IO_MODE=0x0, control enabling of burst mode. Ignored for other
//       IO_MODE values.
//       0x0 = Disable burst mode
//       0x1 = Enable burst mode


       // Read back to confirm SPI write worked
       uint8_t vdrv = TUSS4470_ReadRegister(VDRV_CTRL);
       uint8_t stat = TUSS4470_ReadRegister(DEV_STAT);

       printf("VDRV_CTRL readback = 0x%02X\r\n", vdrv);
       printf("DEV_STAT = 0x%02X, VDRV_READY=%d\r\n", stat, (stat >> 3) & 1);
       TUSS4470_UART_Send("\r\n=== FULL REGISTER READBACK ===\r\n");
       TUSS4470_UART_Send("BPF_CONFIG_1 = 0x%02X (expect 0x1B)\r\n", TUSS4470_ReadRegister(BPF_CONFIG_1));
       TUSS4470_UART_Send("DEV_CTRL_1   = 0x%02X (expect 0x00)\r\n", TUSS4470_ReadRegister(DEV_CTRL_1));
       TUSS4470_UART_Send("DEV_CTRL_2   = 0x%02X (expect 0x00)\r\n", TUSS4470_ReadRegister(DEV_CTRL_2));
       TUSS4470_UART_Send("DEV_CTRL_3   = 0x%02X (expect 0x01)\r\n", TUSS4470_ReadRegister(DEV_CTRL_3));
       TUSS4470_UART_Send("VDRV_CTRL    = 0x%02X (expect 0x5F)\r\n", TUSS4470_ReadRegister(VDRV_CTRL));
       TUSS4470_UART_Send("ECHO_INT     = 0x%02X (expect 0x1F)\r\n", TUSS4470_ReadRegister(ECHO_INT_CONFIG));
       TUSS4470_UART_Send("BURST_PULSE  = 0x%02X (expect 0x0A)\r\n", TUSS4470_ReadRegister(BURST_PULSE));
       TUSS4470_UART_Send("TOF_CONFIG   = 0x%02X (expect 0x02)\r\n", TUSS4470_ReadRegister(TOF_CONFIG));

       TUSS4470_UART_Send("✅ Configuration complete with 1V OUT4 threshold\r\n");
    TUSS4470_LED_Set('G', 0);
}


// =============================================================================
// BURST GENERATION - EXACTLY MATCHING ESP32 CODE
// =============================================================================
void TUSS4470_Generate120kHzClockPulses(int numPulses) {

	    const uint32_t halfPeriodUs = 2; //
	    TUSS4470_UART_Send("Generating %d pulses at 175kHz for 1-40cm range\r\n", numPulses);
	    do_read1 = 1;

	    // 1. Ensure IO2 is HIGH before starting (critical for pulse counting)
	    TUSS4470_IO1_Set(1);
	    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_SET);
	    TUSS4470_DelayUS(20);  // Longer delay for stability

	    // 2. Bring IO1 LOW to enable burst mode (IO_MODE=1)
	    TUSS4470_IO1_Set(0);
	    TUSS4470_DelayUS(20); //(10)

	    // 3. Generate precise 175kHz clock on IO2
	    for(int i = 0; i < 5; i++) {  //changed numPulses to 5
	    	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_RESET);
	        TUSS4470_DelayUS(halfPeriodUs);
	        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_SET);
	        TUSS4470_DelayUS(halfPeriodUs);
	    }

	    // 4. Bring IO1 HIGH to end burst
	    TUSS4470_IO1_Set(1);
	    TUSS4470_UART_Send("Burst complete (33μs duration)\r\n");
}
static void TUSS4470_VDRV_ChargeWaitReady_ThenDisable(void) //this is the code to help listening where its called?
{
    // Turn ON charging
    TUSS4470_WriteRegister(TOF_CONFIG, 0x02);  // VDRV_TRIGGER=1
    TUSS4470_DelayUS(20);
    // Wait for VDRV_READY (DEV_STAT bit 3)
  //  uint32_t t0 = HAL_GetTick();
  //  while (((TUSS4470_ReadRegister(DEV_STAT) & (1U << 3)) == 0) &&
  //         ((HAL_GetTick() - t0) < 50U))
  //  {
        // wait up to 50 ms
  //  }

    // Turn OFF charging immediately before burst (quiet receive)
   // TUSS4470_WriteRegister(TOF_CONFIG, 0x00);  // VDRV_TRIGGER=0
}

/* void TUSS4470_TriggerBurst_IO_MODE1(void)
{
    static uint8_t cachedPulses = 0;
    if (cachedPulses == 0)
    {
        cachedPulses = TUSS4470_ReadRegister(BURST_PULSE) & 0x3F;
    }

    // Enable VDRV charging
    TUSS4470_WriteRegister(TOF_CONFIG, 0x02);

    // Wait for VDRV to actually charge — poll VDRV_READY bit //
    uint32_t t0 = HAL_GetTick();
    while (((TUSS4470_ReadRegister(DEV_STAT) >> 3) & 1) == 0)
    {
        if (HAL_GetTick() - t0 > 50) break;
    }

    TUSS4470_IO1_Set(0);
    TUSS4470_DelayUS(2);
    StartBurst(cachedPulses);
}*/

// Updated burst trigger - re-enables VDRV before each burst
void TUSS4470_TriggerBurst_IO_MODE1(void)
{
    static uint8_t cachedPulses = 0;
    if (cachedPulses == 0)
        cachedPulses = TUSS4470_ReadRegister(BURST_PULSE) & 0x3F;

    // Re-enable VDRV and charge
    TUSS4470_WriteRegister(VDRV_CTRL, 0x4F);   // VDRV_HI_Z=0
    TUSS4470_WriteRegister(TOF_CONFIG, 0x02);   // VDRV_TRIGGER=1

    uint32_t t0 = HAL_GetTick();
    while (((TUSS4470_ReadRegister(DEV_STAT) >> 3) & 1) == 0)
    {
        if (HAL_GetTick() - t0 > 50) break;
    }

    // Stop charging before burst
    TUSS4470_WriteRegister(TOF_CONFIG, 0x00);

    TUSS4470_IO1_Set(0);
    TUSS4470_DelayUS(2);
    StartBurst(cachedPulses);
}

// Simple burst function — ADD THIS RIGHT AFTER
void TUSS4470_GenerateBurst(int numPulses) {
    TUSS4470_UART_Send("Generating %d pulses at 175kHz\r\n", numPulses);
    TUSS4470_TriggerBurst_IO_MODE1();
}

// =============================================================================
// DEVICE STATUS AND DIAGNOSTICS - EXACTLY MATCHING ESP32 CODE
// =============================================================================
void TUSS4470_ReadDeviceStatus(void) {
    TUSS4470_UART_Send("\r\n");
    TUSS4470_UART_Send("=== DEVICE STATUS ===\r\n");

    uint8_t dev_stat = TUSS4470_ReadRegister(DEV_STAT);
    TUSS4470_UART_Send("DEV_STAT (0x1C): 0x%02X\r\n", dev_stat);

    uint8_t device_id = TUSS4470_ReadRegister(DEVICE_ID);
    TUSS4470_UART_Send("DEVICE_ID (0x1D): 0x%02X\r\n", device_id);

    uint8_t rev_id = TUSS4470_ReadRegister(REV_ID);
    TUSS4470_UART_Send("REV_ID (0x1E): 0x%02X\r\n", rev_id);

    // Parse status bits
    TUSS4470_UART_Send("--- Status Breakdown ---\r\n");
    TUSS4470_UART_Send("VDRV_READY: %s\r\n", (dev_stat >> 3) & 0x01 ? "YES" : "NO");
    TUSS4470_UART_Send("PULSE_NUM_FLT: %s\r\n", (dev_stat >> 2) & 0x01 ? "FAULT" : "OK");
    TUSS4470_UART_Send("DRV_PULSE_FLT: %s\r\n", (dev_stat >> 1) & 0x01 ? "FAULT" : "OK");
    TUSS4470_UART_Send("EE_CRC_FLT: %s\r\n", dev_stat & 0x01 ? "FAULT" : "OK");
}

void TUSS4470_VerifyConfiguration(void) {
    TUSS4470_UART_Send("\r\n");
    TUSS4470_UART_Send("=== CONFIGURATION VERIFICATION ===\r\n");

    // Verify key registers
    uint8_t reg_10 = TUSS4470_ReadRegister(BPF_CONFIG_1);
    uint8_t reg_14 = TUSS4470_ReadRegister(DEV_CTRL_3);
    uint8_t reg_1A = TUSS4470_ReadRegister(BURST_PULSE);

    TUSS4470_UART_Send("BPF_CONFIG_1 (0x10): 0x%02X\r\n", reg_10);
    TUSS4470_UART_Send("DEV_CTRL_3 (0x14): 0x%02X\r\n", reg_14);
    TUSS4470_UART_Send("BURST_PULSE (0x1A): 0x%02X\r\n", reg_1A);

    // Check HPF configuration
    bool hpf_enabled = (reg_10 >> 6) & 0x01;
    uint8_t hpf_freq = reg_10 & 0x3F;

    TUSS4470_UART_Send("HPF Enabled: %s\r\n", hpf_enabled ? "YES" : "NO");
    TUSS4470_UART_Send("HPF Frequency: 0x%02X\r\n", hpf_freq);

    // Check IO_MODE
    uint8_t io_mode = reg_14 & 0x03;
    TUSS4470_UART_Send("IO_MODE: %d\r\n", io_mode);

    if (hpf_enabled && (hpf_freq >= 0x20 && hpf_freq <= 0x2F) && io_mode == 1) {
        TUSS4470_UART_Send("✅ Configuration CORRECT\r\n");
    } else {
        TUSS4470_UART_Send("❌ Configuration ERROR\r\n");
    }
}


static void TUSS4470_SingleShot(uint8_t pulses)
{
    if (pulses == 0) pulses = 1;
    if (pulses > 63) pulses = 63;

    // Preserve bits 7:6 (HALF_BRG_MODE, PRE_DRIVER_MODE), replace only pulse count (bits 5:0)
    uint8_t reg = TUSS4470_ReadRegister(BURST_PULSE);
    reg = (reg & 0xC0) | (pulses & 0x3F);
    TUSS4470_WriteRegister(BURST_PULSE, reg);

    // Fire exactly one burst
    TUSS4470_TriggerBurst_IO_MODE1();
}

// =============================================================================
// SIGNAL MONITORING (Matching ESP32 but without ADC for now)
// =============================================================================
void TUSS4470_MonitorVOUTSignal(void) {
}

float TUSS4470_CaptureEcho(void) {
    TUSS4470_UART_Send("=== ECHO CAPTURE ===\r\n");
    TUSS4470_UART_Send("ADC not configured in this version\r\n");
    TUSS4470_UART_Send("Will return simulated distance\r\n");

    // Simulated echo for testing
    TUSS4470_UART_Send("Simulated echo at 500μs\r\n");
    TUSS4470_UART_Send("Distance: 8.6 cm\r\n");

    return 0.086; // Return 8.6 cm in meters
}


void TUSS4470_PerformMeasurement(void)
{
    TUSS4470_UART_Send(">>> MEASUREMENT START <<<\r\n");

    float distance = TUSS4470_MeasureDistance_cm();

    if (distance > 0.5f && distance < 100.0f)
    {
        TUSS4470_UART_Send("Distance = %.2f cm\r\n", distance);
    }
    else
    {
        TUSS4470_UART_Send("No valid echo detected\r\n");
    }
}


// =============================================================================
// CONTINUOUS MODE
// =============================================================================
void TUSS4470_ContinuousMode(void)
{
    uint32_t currentTime = HAL_GetTick();
    if (currentTime - lastBurstTime >= BURST_INTERVAL)
    {
        TUSS4470_TriggerBurst_IO_MODE1();
        lastBurstTime = currentTime;
    }
}



// =============================================================================
// COMMAND PROCESSING - SAME COMMANDS AS ESP32
// =============================================================================
void TUSS4470_PrintHelp(void) {
    TUSS4470_UART_Send("\r\n==================================================\r\n");
    TUSS4470_UART_Send("COMMANDS: MEASU, START, STOP, STATU, MONIT, BURST\r\n");
    TUSS4470_UART_Send("==================================================\r\n");
}

void TUSS4470_ParseCommand(char* cmd_str, Command_t* cmd) {
    memset(cmd, 0, sizeof(Command_t));

    char* token = strtok(cmd_str, " ");
    if(token) {
        strncpy(cmd->command, token, sizeof(cmd->command)-1);
        cmd->command[sizeof(cmd->command)-1] = '\0';

        // Convert to uppercase
        for(int i = 0; cmd->command[i]; i++) {
            cmd->command[i] = toupper(cmd->command[i]);
        }

        // Parse parameters
        cmd->num_params = 0;
        while((token = strtok(NULL, " ")) != NULL && cmd->num_params < MAX_PARAMS) {
            cmd->params[cmd->num_params++] = atoi(token);
        }
    }
}

void TUSS4470_ProcessCommand(Command_t* cmd) {
    TUSS4470_UART_Send("\r\n");

    if(strcmp(cmd->command, "MEASURE") == 0) {
        TUSS4470_PerformMeasurement();
    }

    else if(strcmp(cmd->command, "START") == 0 ) {
        continuousBurstEnabled = true;
        TUSS4470_UART_Send("Continuous mode STARTED\r\n");

    }
    else if(strcmp(cmd->command, "STOP") == 0 ) {
        continuousBurstEnabled = false;
        TUSS4470_UART_Send("Continuous mode STOPPED\r\n");
    }
    else if(strcmp(cmd->command, "STATUS") == 0) {
        TUSS4470_ReadDeviceStatus();
    }
    else if(strcmp(cmd->command, "MONITOR") == 0) {
        TUSS4470_MonitorVOUTSignal();
    }
    else if(strcmp(cmd->command, "BURST") == 0) {
        uint16_t num_pulses = (cmd->num_params > 0) ? cmd->params[0] : 16;
        TUSS4470_GenerateBurst(num_pulses);
    }
    else if(strcmp(cmd->command, "CONFIG") == 0) {
        TUSS4470_ConfigureTUSS4470();
    }
    else if(strcmp(cmd->command, "VERIFY") == 0) {
        TUSS4470_VerifyConfiguration();
    }
    else if(strcmp(cmd->command, "HELP") == 0) {
        TUSS4470_PrintHelp();
    }
    else {
        TUSS4470_UART_Send("Unknown command: %s\r\n", cmd->command);
        TUSS4470_UART_Send("Type 'HELP' for available commands\r\n");
    }

    TUSS4470_UART_Send("\r\nTUSS4470> ");
}



float TUSS4470_MeasureDistance_cm(void)
{
    echo_received = 0;

    /* Start time-of-flight */
    tof_start_us = micros();

    /* Trigger ultrasonic burst */
    TUSS4470_TriggerBurst_IO_MODE1();

    /* Wait for echo (timeout = 3ms ≈ 50cm) */
    uint32_t start_wait = micros();
    while (!echo_received)
    {
        if ((micros() - start_wait) > 3000)
        {
            return -1.0f; // No echo
        }
    }

    uint32_t tof_us = tof_stop_us - tof_start_us;

    /* Distance = (TOF × speed_of_sound) / 2 */
    /* speed_of_sound ≈ 343 m/s = 0.0343 cm/us */
    return tof_us * 0.01715f;
}

// =============================================================================
// INITIALIZATION FUNCTION
// =============================================================================
void TUSS4470_Init(void) {
    TUSS4470_UART_Send("\r\n");
    TUSS4470_UART_Send("==================================================\r\n");
    TUSS4470_UART_Send("TUSS4470 - CORRECTED CONFIGURATION (TI REFERENCE)\r\n");
    TUSS4470_UART_Send("HPF: OFF, IO_MODE: 1, Frequency: 175kHz\r\n");
    TUSS4470_UART_Send("STM32H743VIT6 Version\r\n");
    TUSS4470_UART_Send("==================================================\r\n");

    // Configure GPIOs exactly as ESP32 code
    TUSS4470_CS_High();
    TUSS4470_IO1_Set(1); // Critical: Start HIGH (as in ESP32 code)
  //  TUSS4470_IO2_Set(1); // Critical: Start HIGH (as in ESP32 code)

    HAL_Delay(500);

    // Configure device (exactly matching ESP32 configuration)
    TUSS4470_ConfigureTUSS4470();

    // Initial diagnostics (same as ESP32)
    TUSS4470_ReadDeviceStatus();
    TUSS4470_VerifyConfiguration();
    TUSS4470_MonitorVOUTSignal();

    // Test measurement
    TUSS4470_PerformMeasurement();

    TUSS4470_UART_Send("\r\n");
    TUSS4470_PrintHelp();
    TUSS4470_UART_Send("\r\nTUSS4470> ");
}


