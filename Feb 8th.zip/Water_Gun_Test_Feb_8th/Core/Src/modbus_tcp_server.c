

#include "modbus_tcp_server.h"
#include "lwip/debug.h"
#include "lwip/stats.h"
#include "lwip/tcp.h"
#include "main.h"
#include "string.h"
#include <stdlib.h>  // For malloc() and free()





#define MODBUS_COIL_COUNT 10 // Example number of coils
uint8_t modbus_coils[MODBUS_COIL_COUNT]; // Array to store coil states (0 or 1)

#define MODBUS_INPUT_COUNT 10 // Example number of discrete inputs
uint8_t modbus_inputs[MODBUS_INPUT_COUNT]; // Array to store input states (0 or 1)

#define MODBUS_HOLDING_REGISTER_COUNT 10 // Example count of holding registers
uint16_t modbus_holding_registers[MODBUS_HOLDING_REGISTER_COUNT]; // Array for holding register values

#define MODBUS_INPUT_REGISTER_COUNT 10 // Example size of input register array
uint16_t modbus_input_registers[MODBUS_INPUT_REGISTER_COUNT]; // Input register storage

uint8_t SLAVE_ID=0x01;


struct tcp_pcb *modbus_tcp_pcb;

/* ECHO protocol states */
enum modbus_tcp_states
{
  ES_NONE = 0,
  ES_ACCEPTED,
  ES_RECEIVED,
  ES_CLOSING
};

/* structure for maintaining connection infos to be passed as argument
   to LwIP callbacks*/
struct modbus_tcp_struct
{
  u8_t state;             /* current connection state */
  u8_t retries;
  struct tcp_pcb *pcb;    /* pointer on the current tcp_pcb */
  struct pbuf *p;         /* pointer on the received/to be transmitted pbuf */
};


static err_t modbus_tcp_accept(void *arg, struct tcp_pcb *newpcb, err_t err);
static err_t modbus_tcp_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err);
static void modbus_tcp_error(void *arg, err_t err);
static err_t modbus_tcp_poll(void *arg, struct tcp_pcb *tpcb);
static err_t modbus_tcp_sent(void *arg, struct tcp_pcb *tpcb, u16_t len);
static void modbus_tcp_send(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
static void modbus_tcp_connection_close(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_process_request(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_read_holding_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_read_input_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_read_coils(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_read_inputs(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_write_single_register(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_write_multiple_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_write_single_coil(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_write_multiple_coils(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
void modbus_send_response(struct tcp_pcb *pcb,  void *arg, u16_t len, u8_t apiflags);
void modbus_illegal_function_exception(struct tcp_pcb *tpcb, uint8_t unit_id, uint8_t function_code, uint16_t transaction_id);
void modbus_read_write_multiple_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es);
/**
  * @brief  Initializes the tcp echo server
  * @param  None
  * @retval None
  */
void modbus_tcp_init(void)
{
  /* create new tcp pcb */
	modbus_tcp_pcb = tcp_new();

  if (modbus_tcp_pcb != NULL)
  {
    err_t err;

    /* bind echo_pcb to port 7 (ECHO protocol) */
    err = tcp_bind(modbus_tcp_pcb, IP_ADDR_ANY, 502);

   if (err == ERR_OK)
   {
      /* start tcp listening for echo_pcb */
	   modbus_tcp_pcb = tcp_listen(modbus_tcp_pcb);

      /* initialize LwIP tcp_accept callback function */
      tcp_accept(modbus_tcp_pcb, modbus_tcp_accept);

    }
    else
    {

      /* deallocate the pcb */
     // memp_free(MEMP_TCP_PCB, modbus_tcp_pcb);
    }
  }
}

/**
  * @brief  This function is the implementation of tcp_accept LwIP callback
  * @param  arg: not used
  * @param  newpcb: pointer on tcp_pcb struct for the newly created tcp connection
  * @param  err: not used
  * @retval err_t: error status
  */
static err_t modbus_tcp_accept(void *arg, struct tcp_pcb *newpcb, err_t err)
{
  err_t ret_err;
  struct modbus_tcp_struct *es;

  LWIP_UNUSED_ARG(arg);
  LWIP_UNUSED_ARG(err);

  /* set priority for the newly accepted tcp connection newpcb */
  tcp_setprio(newpcb, TCP_PRIO_MIN);

  /* allocate structure es to maintain tcp connection information */
  es = (struct modbus_tcp_struct *)mem_malloc(sizeof(struct modbus_tcp_struct));
  if (es != NULL)
  {
    es->state = ES_ACCEPTED;
    es->pcb = newpcb;
    es->retries = 0;
    es->p = NULL;

    /* pass newly allocated es structure as argument to newpcb */
    tcp_arg(newpcb, es);

    /* initialize lwip tcp_recv callback function for newpcb  */
    tcp_recv(newpcb, modbus_tcp_recv);

    /* initialize lwip tcp_err callback function for newpcb  */
    tcp_err(newpcb, modbus_tcp_error);


    /* initialize lwip tcp_poll callback function for newpcb */
    tcp_poll(newpcb, modbus_tcp_poll, 0);

    ret_err = ERR_OK;
  }
  else
  {

    /*  close tcp connection */
    modbus_tcp_connection_close(newpcb, es);
    /* return memory error */
    ret_err = ERR_MEM;
  }
  return ret_err;
}


/**
  * @brief  This function is the implementation for tcp_recv LwIP callback
  * @param  arg: pointer on a argument for the tcp_pcb connection
  * @param  tpcb: pointer on the tcp_pcb connection
  * @param  pbuf: pointer on the received pbuf
  * @param  err: error information regarding the reveived pbuf
  * @retval err_t: error code
  */

static err_t modbus_tcp_recv(void *arg, struct tcp_pcb *tpcb, struct pbuf *p, err_t err)
{
    struct modbus_tcp_struct *es = (struct modbus_tcp_struct *)arg;

    if (p == NULL) {
        // Connection closed by the client
        modbus_tcp_connection_close(tpcb, es);
        return ERR_OK;
    }

    if (err != ERR_OK) {
        // Handle error
        if (p != NULL) {
            pbuf_free(p);
        }
        return err;
    }

    // Process the received data
    if (es->state == ES_ACCEPTED || es->state == ES_RECEIVED) {
        es->state = ES_RECEIVED;
        es->p = p;

        // Process the Modbus request
        modbus_process_request(tpcb, es);

        // Acknowledge the received data
        tcp_recved(tpcb, p->tot_len);

        // Free the pbuf after processing
        pbuf_free(p);
        es->p = NULL;
    }

    return ERR_OK;
}

/**
  * @brief  This function implements the tcp_err callback function (called
  *         when a fatal tcp_connection error occurs.
  * @param  arg: pointer on argument parameter
  * @param  err: not used
  * @retval None
  */
static void modbus_tcp_error(void *arg, err_t err)
{
  struct modbus_tcp_struct *es;

  LWIP_UNUSED_ARG(err);

  es = (struct modbus_tcp_struct *)arg;
  if (es != NULL)
  {
    /*  free es structure */
    mem_free(es);
  }
}

/**
  * @brief  This function implements the tcp_poll LwIP callback function
  * @param  arg: pointer on argument passed to callback
  * @param  tpcb: pointer on the tcp_pcb for the current tcp connection
  * @retval err_t: error code
  */
static err_t modbus_tcp_poll(void *arg, struct tcp_pcb *tpcb)
{
  err_t ret_err;
  struct modbus_tcp_struct *es;

  es = (struct modbus_tcp_struct *)arg;
  if (es != NULL)
  {
    if (es->p != NULL)
    {

      tcp_sent(tpcb, modbus_tcp_sent);

      modbus_tcp_send(tpcb, es);

    }
    else
    {
      /* no remaining pbuf (chain)  */
      if(es->state == ES_CLOSING)
      {
        /*  close tcp connection */
        modbus_tcp_connection_close(tpcb, es);
      }
    }
    ret_err = ERR_OK;
  }
  else
  {
    /* nothing to be done */
    tcp_abort(tpcb);
    ret_err = ERR_ABRT;
  }
  return ret_err;
}

/**
  * @brief  This function implements the tcp_sent LwIP callback (called when ACK
  *         is received from remote host for sent data)
  * @param  None
  * @retval None
  */
static err_t modbus_tcp_sent(void *arg, struct tcp_pcb *tpcb, u16_t len)
{
  struct modbus_tcp_struct *es;

  LWIP_UNUSED_ARG(len);

  es = (struct modbus_tcp_struct *)arg;
  es->retries = 0;

  if(es->p != NULL)
  {
    /* still got pbufs to send */
   tcp_sent(tpcb, modbus_tcp_sent);
    modbus_tcp_send(tpcb, es);
  }
  else
  {
    /* if no more data to send and client closed connection*/
    if(es->state == ES_CLOSING)
      modbus_tcp_connection_close(tpcb, es);
  }
  return ERR_OK;
}


/**
  * @brief  This function is used to send data for tcp connection
  * @param  tpcb: pointer on the tcp_pcb connection
  * @param  es: pointer on echo_state structure
  * @retval None
  */
static void modbus_tcp_send(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
  struct pbuf *ptr;
  err_t wr_err = ERR_OK;

  while ((wr_err == ERR_OK) &&
         (es->p != NULL) &&
         (es->p->len <= tcp_sndbuf(tpcb)))
  {

    /* get pointer on pbuf from es structure */
	//es->p = NULL;
    ptr = es->p;
   // es->p != NULL;

    /* enqueue data for transmission */
    wr_err = tcp_write(tpcb, ptr->payload, ptr->len, 1);

    if (wr_err == ERR_OK)
    {
      u16_t plen;
      u8_t freed;

      plen = ptr->len;

      /* continue with next pbuf in chain (if any) */
      es->p = ptr->next;

      if(es->p != NULL)
      {
        /* increment reference count for es->p */
        pbuf_ref(es->p);
      }

     /* chop first pbuf from chain */
      do
      {
        /* try hard to free pbuf */
        freed = pbuf_free(ptr);
      }
      while(freed == 0);
     /* we can read more data now */
     tcp_recved(tpcb, plen);
   }
   else if(wr_err == ERR_MEM)
   {
      /* we are low on memory, try later / harder, defer to poll */
     es->p = ptr;
   }
   else
   {
     /* other problem ?? */
   }
  }
}

/**
  * @brief  This functions closes the tcp connection
  * @param  tcp_pcb: pointer on the tcp connection
  * @param  es: pointer on echo_state structure
  * @retval None
  */
static void modbus_tcp_connection_close(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{

  /* remove all callbacks */
  tcp_arg(tpcb, NULL);
  tcp_sent(tpcb, NULL);
  tcp_recv(tpcb, NULL);
  tcp_err(tpcb, NULL);
  tcp_poll(tpcb, NULL, 0);

  /* delete es structure */
  if (es != NULL)
  {
    mem_free(es);
  }

  /* close tcp connection */
  tcp_close(tpcb);
}


// Function to process incoming Modbus TCP requests
void modbus_process_request(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Ensure the provided Modbus structure is valid
    if (es == NULL || es->p == NULL)
    {
        return; // Exit if the structure is invalid
    }

    // Pointer to the received Modbus TCP request payload
    struct pbuf *ptr = es->p;

    // Validate the payload pointer
    if (ptr == NULL || ptr->payload == NULL)
    {
        return; // Exit if the payload is NULL
    }

    // Cast payload to a Modbus data buffer
    uint8_t *data = (uint8_t *)ptr->payload;

    // Ensure the packet contains at least the minimum Modbus TCP request length
    if (ptr->len < 8)
    {
        return; // Exit if the request is too short
    }

    // Extract Modbus Unit ID (Slave Address) and Function Code
    uint8_t unit_id = data[6];  // Unit ID (Slave Address)
    uint8_t function_code = data[7];  // Function Code

    // Check if the request is meant for this slave (Optional ID Filtering)
    // if (unit_id != SLAVE_ID) return;  // Uncomment if slave filtering is needed

    // Process the request based on the function code
    switch (function_code)
    {
        case 0x03:  // Read Holding Registers
            modbus_read_holding_registers(tpcb, es);
            break;

        case 0x04:  // Read Input Registers
            modbus_read_input_registers(tpcb, es);
            break;

         case 0x01:  // Read Coils
             modbus_read_coils(tpcb, es);
             break;

         case 0x02:  // Read Discrete Inputs
             modbus_read_inputs(tpcb, es);
             break;

        case 0x06:  // Write Single Register
            modbus_write_single_register(tpcb, es);
            break;

        case 0x10:  // Write Multiple Registers
            modbus_write_multiple_registers(tpcb, es);
            break;

         case 0x05:  // Write Single Coil
             modbus_write_single_coil(tpcb, es);
             break;

         case 0x0F:  // Write Multiple Coils
             modbus_write_multiple_coils(tpcb, es);
             break;

        case 0x17:  // Read/Write Multiple Registers
            modbus_read_write_multiple_registers(tpcb, es);
            break;

        default:
            // Send an exception response for unsupported function codes
            modbus_illegal_function_exception(tpcb, unit_id, function_code, (data[0] << 8) | data[1]);
            break;
    }
}


void modbus_read_write_multiple_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es) {
    struct pbuf *ptr = es->p;
    uint8_t *request = ptr->payload;

    uint16_t read_start_address = (request[8] << 8) | request[9];
    uint16_t read_register_count = (request[10] << 8) | request[11];
    uint16_t write_start_address = (request[12] << 8) | request[13];
    uint16_t write_register_count = (request[14] << 8) | request[15];
    uint8_t write_byte_count = request[16];

    if (read_start_address >= MODBUS_HOLDING_REGISTER_COUNT ||
        (read_start_address + read_register_count) > MODBUS_HOLDING_REGISTER_COUNT ||
        write_start_address >= MODBUS_HOLDING_REGISTER_COUNT ||
        (write_start_address + write_register_count) > MODBUS_HOLDING_REGISTER_COUNT ||
        write_byte_count != (write_register_count * 2)) {
        uint8_t exception_response[9] = {
            request[0], request[1], request[2], request[3], 0x00, 0x03,
            request[6], request[7] | 0x80, 0x02
        };
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        return;
    }

    // Prepare response with read values first
    uint16_t response_length = 9 + (read_register_count * 2);
    uint8_t response[response_length];

    response[0] = request[0];
    response[1] = request[1];
    response[2] = request[2];
    response[3] = request[3];
    response[4] = (response_length - 6) >> 8;
    response[5] = (response_length - 6) & 0xFF;
    response[6] = request[6];
    response[7] = request[7];
    response[8] = read_register_count * 2;

    for (uint16_t i = 0; i < read_register_count; i++) {
        uint16_t register_value = modbus_holding_registers[read_start_address + i];
        response[9 + (i * 2)] = (register_value >> 8) & 0xFF;
        response[10 + (i * 2)] = register_value & 0xFF;
    }

    // Send the response before writing registers to avoid delay
    modbus_send_response(tpcb, response, response_length, TCP_WRITE_FLAG_COPY);

    // Now process write request in the background
    for (uint16_t i = 0; i < write_register_count; i++) {
        uint16_t value = (request[17 + (i * 2)] << 8) | request[18 + (i * 2)];
        modbus_holding_registers[write_start_address + i] = value;
    }
}


// Function to process "Read Holding Registers" (Function Code 3)
void modbus_read_holding_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{

        struct pbuf *ptr = es->p;
        uint8_t *request = ptr->payload;

        // Extract request details
        uint16_t start_address = (request[8] << 8) | request[9];  // Start address
        uint16_t register_count = (request[10] << 8) | request[11]; // Number of registers

        // Validate the register range
        if (start_address >= MODBUS_HOLDING_REGISTER_COUNT ||
            (start_address + register_count) > MODBUS_HOLDING_REGISTER_COUNT ||
            register_count == 0)
        {
            // Respond with an error if the range is invalid
            // Modbus exception for illegal data address
            uint8_t exception_response[9] = {
                request[0], request[1],  // Transaction ID
				request[2], request[3],              // Protocol ID
                0x00, 0x03,              // Length (3 bytes: unit ID, function code, exception code)
                request[6],              // Unit ID
                request[7] | 0x80,       // Function code with error flag
                0x02                     // Exception code: Illegal Data Address
            };

            // Send the exception response
            modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
            //tcp_output(tpcb);
            return;
        }
    // Prepare the response buffer
        uint16_t response_length = 9 + register_count * 2; // Header + Unit ID + Function Code + Byte Count + Register Values
        uint8_t response[response_length];

        // Modbus TCP Header
        response[0] = request[0];  // Transaction ID High
        response[1] = request[1];  // Transaction ID Low
        response[2] = request[2];        // Protocol ID High
        response[3] = request[3];;        // Protocol ID Low
        response[4] = (response_length - 6) >> 8; // Length High (exclude Transaction ID & Protocol ID)
        response[5] = (response_length - 6) & 0xFF; // Length Low
        response[6] = request[6];  // Unit ID
        response[7] = request[7];  // Function Code

        // Byte count
        response[8] = register_count * 2;

        // Read the registers and populate the response
        for (uint16_t i = 0; i < register_count; i++) {
            uint16_t register_value = modbus_holding_registers[start_address + i];
            response[9 + i * 2] = (register_value >> 8) & 0xFF;  // High byte
            response[10 + i * 2] = register_value & 0xFF;        // Low byte
        }

        // Send the response
        modbus_send_response(tpcb, response, response_length, TCP_WRITE_FLAG_COPY);
        //tcp_output(tpcb);


}
void modbus_read_input_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Validate input pointers to avoid null pointer dereference
    if (es == NULL || es->p == NULL || es->p->payload == NULL)
    {
        return; // Invalid packet, exit function
    }

    struct pbuf *ptr = es->p;       // Pointer to the received Modbus TCP request
    uint8_t *request = ptr->payload; // Extract payload from the received packet

    // Extract the starting address and number of registers to read (big-endian format)
    uint16_t start_address = (request[8] << 8) | request[9];
    uint16_t register_count = (request[10] << 8) | request[11];

    // Validate the requested register range
    if (start_address >= MODBUS_INPUT_REGISTER_COUNT ||
        (start_address + register_count) > MODBUS_INPUT_REGISTER_COUNT ||
        register_count == 0)
    {
        // Prepare an exception response for an invalid address or range
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
			request[2], request[3],              // Protocol ID (always 0 for Modbus TCP)
            0x00, 0x03,              // Length of response (3 bytes: Unit ID, Function Code, Exception Code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function Code with exception flag
            0x02                     // Exception Code: Illegal Data Address
        };

        // Send the exception response to the client
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        return;
    }

    // Calculate the response length:
    // 9 bytes for the header + 2 bytes per register
    uint16_t response_length = 9 + (register_count * 2);

    // Allocate memory dynamically for the response buffer
    uint8_t *response = (uint8_t *)malloc(response_length);
    if (response == NULL)
    {
        return; // Memory allocation failed, exit function
    }

    // Prepare the Modbus TCP response header
    response[0] = request[0];      // Transaction ID high byte
    response[1] = request[1];      // Transaction ID low byte
    response[2] = request[2];            // Protocol ID high byte
    response[3] = request[3];            // Protocol ID low byte
    response[4] = (response_length - 6) >> 8; // Length high byte
    response[5] = (response_length - 6) & 0xFF; // Length low byte
    response[6] = request[6];      // Unit ID
    response[7] = request[7];      // Function Code
    response[8] = register_count * 2; // Byte count (2 bytes per register)

    // Read the input registers and populate the response buffer
    for (uint16_t i = 0; i < register_count; i++)
    {
        uint16_t register_value = modbus_input_registers[start_address + i];

        // Store the register value in big-endian format (high byte first)
        response[9 + (i * 2)] = (register_value >> 8) & 0xFF; // High byte
        response[10 + (i * 2)] = register_value & 0xFF;       // Low byte
    }

    // Send the response to the client
    modbus_send_response(tpcb, response, response_length, TCP_WRITE_FLAG_COPY);

    // Free allocated memory
    free(response);
}


void modbus_read_coils(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Pointer to the Modbus TCP request payload
    struct pbuf *ptr = es->p;
    uint8_t *request = ptr->payload;

    // Extract request details
    uint16_t start_address = (request[8] << 8) | request[9];  // Start address
    uint16_t coil_count = (request[10] << 8) | request[11];   // Number of coils

    // Validate the coil range
    if (start_address >= MODBUS_COIL_COUNT ||
        (start_address + coil_count) > MODBUS_COIL_COUNT ||
        coil_count == 0 ||
        coil_count > 2000) // Modbus limits reading up to 2000 coils in one request
    {
        // Respond with an error if the range is invalid
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
			request[2], request[3],              // Protocol ID
            0x00, 0x03,              // Length (3 bytes: unit ID, function code, exception code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function code with error flag
            0x02                     // Exception code: Illegal Data Address
        };

        // Send the exception response
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
       // tcp_output(tpcb);
        return;
    }

    // Calculate the number of bytes needed to represent the coil values
    uint16_t byte_count = (coil_count + 7) / 8;

    // Prepare the response buffer
    uint16_t response_length = 9 + byte_count; // Header + Unit ID + Function Code + Byte Count + Coil Values
    uint8_t response[response_length];

    // Modbus TCP Header
    response[0] = request[0];  // Transaction ID High
    response[1] = request[1];  // Transaction ID Low
    response[2] = request[2];        // Protocol ID High
    response[3] = request[3];        // Protocol ID Low
    response[4] = (response_length - 6) >> 8; // Length High (exclude Transaction ID & Protocol ID)
    response[5] = (response_length - 6) & 0xFF; // Length Low
    response[6] = request[6];  // Unit ID
    response[7] = request[7];  // Function Code

    // Byte count
    response[8] = byte_count;

    // Read the coil values and populate the response
    for (uint16_t i = 0; i < coil_count; i++) {
        uint16_t coil_index = start_address + i;
        uint8_t coil_value = modbus_coils[coil_index] ? 1 : 0; // Retrieve the coil state (1 or 0)

        // Pack the coil values into the response buffer
        uint16_t byte_index = 9 + (i / 8);  // Byte index in response
        uint8_t bit_index = i % 8;          // Bit position in the byte
        if (coil_value) {
            response[byte_index] |= (1 << bit_index); // Set the bit if the coil is ON
        } else {
            response[byte_index] &= ~(1 << bit_index); // Clear the bit if the coil is OFF
        }
    }

    // Send the response
    modbus_send_response(tpcb, response, response_length, TCP_WRITE_FLAG_COPY);
   // tcp_output(tpcb);
}


void modbus_read_inputs(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Ensure the pointer to the Modbus request payload is valid
    if (es == NULL || es->p == NULL || es->p->payload == NULL)
    {
        return; // Invalid packet, exit function
    }

    struct pbuf *ptr = es->p;      // Pointer to the received Modbus TCP request
    uint8_t *request = ptr->payload; // Extract payload from the received packet

    // Extract the starting address and number of inputs to read (big-endian format)
    uint16_t start_address = (request[8] << 8) | request[9];
    uint16_t input_count = (request[10] << 8) | request[11];

    // Validate the requested input range
    if (start_address >= MODBUS_INPUT_COUNT ||
        (start_address + input_count) > MODBUS_INPUT_COUNT ||
        input_count == 0 || input_count > 2000) // Modbus allows reading up to 2000 inputs per request
    {
        // Prepare an exception response for an invalid address or range
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
			request[2], request[3],              // Protocol ID (always 0 for Modbus TCP)
            0x00, 0x03,              // Length of response (3 bytes: Unit ID, Function Code, Exception Code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function Code with exception flag
            0x02                     // Exception Code: Illegal Data Address
        };

        // Send the exception response to the client
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        return;
    }

    // Calculate the number of bytes required to store the input values
    uint16_t byte_count = (input_count + 7) / 8;

    // Allocate memory dynamically for the response
    uint16_t response_length = 9 + byte_count; // Header + Unit ID + Function Code + Byte Count + Input Data
    uint8_t *response = (uint8_t *)malloc(response_length);
    if (response == NULL)
    {
        return; // Memory allocation failed, exit function
    }

    // Prepare the Modbus TCP response header
    response[0] = request[0];      // Transaction ID high byte
    response[1] = request[1];      // Transaction ID low byte
    response[2] = request[2];            // Protocol ID high byte
    response[3] = request[3];            // Protocol ID low byte
    response[4] = (response_length - 6) >> 8; // Length high byte
    response[5] = (response_length - 6) & 0xFF; // Length low byte
    response[6] = request[6];      // Unit ID
    response[7] = request[7];      // Function Code
    response[8] = byte_count;      // Number of bytes following

    // Initialize the response data area
    memset(&response[9], 0, byte_count);

    // Read the input values and pack them into the response buffer
    for (uint16_t i = 0; i < input_count; i++)
    {
        uint16_t input_index = start_address + i;
        uint8_t input_value = modbus_inputs[input_index] ? 1 : 0; // Get input state (1 or 0)

        uint16_t byte_index = 9 + (i / 8); // Determine the correct byte index
        uint8_t bit_index = i % 8;         // Determine the bit position in that byte

        if (input_value)
        {
            response[byte_index] |= (1 << bit_index); // Set the bit if input is ON
        }
    }

    // Send the response to the client
    modbus_send_response(tpcb, response, response_length, TCP_WRITE_FLAG_COPY);

    // Free allocated memory
    free(response);
}


void modbus_write_single_register(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Ensure the pointer to the Modbus request payload is valid
    if (es == NULL || es->p == NULL || es->p->payload == NULL)
    {
        return; // Invalid packet, exit function
    }

    struct pbuf *ptr = es->p;      // Pointer to the received Modbus TCP request
    uint8_t *request = ptr->payload; // Extract payload from the received packet

    // Extract the register address and value (big-endian format)
    uint16_t register_address = (request[8] << 8) | request[9];
    uint16_t register_value = (request[10] << 8) | request[11];

    // Validate the register address to prevent out-of-bounds access
    if (register_address >= MODBUS_HOLDING_REGISTER_COUNT)
    {
        // Prepare an exception response for an invalid register address
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
			request[2], request[3],              // Protocol ID
            0x00, 0x03,              // Length (3 bytes: Unit ID, Function Code, Exception Code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function Code with error flag
            0x02                     // Exception Code: Illegal Data Address
        };

        // Send the exception response to the client
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        return;
    }

    // Write the received value to the specified register
    modbus_holding_registers[register_address] = register_value;

    // Allocate memory for response (Modbus spec requires echoing the request)
    uint8_t *response = (uint8_t *)malloc(12);
    if (response == NULL)
    {
        return; // Memory allocation failed, exit function
    }

    // Copy the request directly into the response
    memcpy(response, request, 12);

    // Send the response (echo back the request)
    modbus_send_response(tpcb, response, 12, TCP_WRITE_FLAG_COPY);

    // Free allocated memory
    free(response);
}




void modbus_write_multiple_registers(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Ensure the pointer to the Modbus request payload is valid
    if (es == NULL || es->p == NULL || es->p->payload == NULL)
    {
        return; // Invalid packet, exit function
    }

    struct pbuf *ptr = es->p;     // Pointer to the received Modbus TCP request
    uint8_t *request = ptr->payload; // Extract payload from the received packet

    // Extract the starting address from the request (big-endian format)
    uint16_t starting_address = (request[8] << 8) | request[9];

    // Extract the number of registers to write (big-endian format)
    uint16_t register_count = (request[10] << 8) | request[11];

    // Extract the byte count (should be equal to register_count * 2)
    uint8_t byte_count = request[12];

    // Validate address range to prevent out-of-bounds access
    if (starting_address >= MODBUS_HOLDING_REGISTER_COUNT ||
        (starting_address + register_count) > MODBUS_HOLDING_REGISTER_COUNT)
    {
        // Prepare an exception response for an invalid address
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
			request[2], request[3],              // Protocol ID (always 0 for Modbus TCP)
            0x00, 0x03,              // Length of response (3 bytes: Unit ID, Function Code, Exception Code)
            request[6],              // Unit ID (same as received request)
            request[7] | 0x80,       // Function Code with exception flag
            0x02                     // Exception Code: Illegal Data Address
        };

        // Send the exception response to the client
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        return;
    }

    // Validate the byte count to ensure it matches the expected size
    if (byte_count != register_count * 2)
    {
        // Prepare an exception response for an invalid data value
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
			request[2], request[3],              // Protocol ID
            0x00, 0x03,              // Length (3 bytes: Unit ID, Function Code, Exception Code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function Code with error flag
            0x03                     // Exception Code: Illegal Data Value
        };

        // Send the exception response to the client
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        return;
    }

    // Allocate memory safely for writing register values
    uint16_t *temp_registers = (uint16_t *)malloc(register_count * sizeof(uint16_t));
    if (temp_registers == NULL)
    {
        // Memory allocation failed, send an exception response
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
			request[2], request[3],              // Protocol ID
            0x00, 0x03,              // Length (3 bytes: Unit ID, Function Code, Exception Code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function Code with error flag
            0x04                     // Exception Code: Server Device Failure (Memory allocation failed)
        };

        // Send the exception response to the client
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        return;
    }

    // Copy values from the request to the temporary buffer before writing to registers
    for (uint16_t i = 0; i < register_count; i++)
    {
        temp_registers[i] = (request[13 + (i * 2)] << 8) | request[14 + (i * 2)];
    }

    // Now, copy the values from the temporary buffer to the Modbus holding registers
    memcpy(&modbus_holding_registers[starting_address], temp_registers, register_count * sizeof(uint16_t));

    // Free allocated memory
    free(temp_registers);

    // Prepare the success response
    uint8_t response[12];
    response[0] = request[0];      // Transaction ID high byte
    response[1] = request[1];      // Transaction ID low byte
    response[2] = request[2];            // Protocol ID high byte
    response[3] = request[3];            // Protocol ID low byte
    response[4] = 0x00;            // Length high byte
    response[5] = 0x06;            // Length low byte (6 bytes after Unit ID)
    response[6] = request[6];      // Unit ID
    response[7] = request[7];      // Function Code
    response[8] = request[8];      // Starting address high byte
    response[9] = request[9];      // Starting address low byte
    response[10] = request[10];    // Register count high byte
    response[11] = request[11];    // Register count low byte

    // Send the success response back to the client
    modbus_send_response(tpcb, response, sizeof(response), TCP_WRITE_FLAG_COPY);
}



void modbus_write_single_coil(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Pointer to the Modbus TCP request payload
    struct pbuf *ptr = es->p;
    uint8_t *request = ptr->payload;

    // Extract request details
    uint16_t coil_address = (request[8] << 8) | request[9];  // Coil address
    uint16_t coil_value = (request[10] << 8) | request[11];  // Coil value (0xFF00 for ON, 0x0000 for OFF)

    // Validate the request
    if (coil_address >= MODBUS_COIL_COUNT)
    {
        // Respond with an error if the coil address is invalid
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
            request[2], request[3],              // Protocol ID
            0x00, 0x03,              // Length (3 bytes: unit ID, function code, exception code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function code with error flag
            0x02                     // Exception code: Illegal Data Address
        };

        // Send the exception response
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
       // tcp_output(tpcb);
        return;
    }

    if (coil_value != 0xFF00 && coil_value != 0x0000)
    {
        // Respond with an error if the coil value is not valid
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
            request[2], request[3],              // Protocol ID
            0x00, 0x03,              // Length (3 bytes: unit ID, function code, exception code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function code with error flag
            0x03                     // Exception code: Illegal Data Value
        };

        // Send the exception response
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
       // tcp_output(tpcb);
        return;
    }

    // Write the coil value
    if (coil_value == 0xFF00)
    {
        modbus_coils[coil_address] = 1;  // Set the coil to ON
    }
    else
    {
        modbus_coils[coil_address] = 0;  // Set the coil to OFF
    }

    // Prepare the response (echoes the request)
    uint8_t response[12];
    response[0] = request[0];                 // Transaction ID high byte
    response[1] = request[1];                 // Transaction ID low byte
    response[2] = request[2];                       // Protocol ID high byte
    response[3] = request[3];                       // Protocol ID low byte
    response[4] = 0x00;                       // Length high byte
    response[5] = 0x06;                       // Length low byte (6 bytes follow Unit ID)
    response[6] = request[6];                 // Unit ID
    response[7] = request[7];                 // Function code
    response[8] = request[8];                 // Coil address high byte
    response[9] = request[9];                 // Coil address low byte
    response[10] = request[10];               // Coil value high byte
    response[11] = request[11];               // Coil value low byte

    // Send the response
    modbus_send_response(tpcb, response, sizeof(response), TCP_WRITE_FLAG_COPY);
   // tcp_output(tpcb);
}


void modbus_write_multiple_coils(struct tcp_pcb *tpcb, struct modbus_tcp_struct *es)
{
    // Pointer to the Modbus TCP request payload
    struct pbuf *ptr = es->p;
    uint8_t *request = ptr->payload;

    // Extract request details
    uint16_t start_address = (request[8] << 8) | request[9];  // Starting coil address
    uint16_t quantity = (request[10] << 8) | request[11];     // Number of coils to write
//    uint8_t byte_count = request[12];                         // Number of data bytes
    uint8_t *coil_values = &request[13];                      // Pointer to the coil values

    // Validate the request
    if (start_address >= MODBUS_COIL_COUNT || (start_address + quantity) > MODBUS_COIL_COUNT)
    {
        // Respond with an error if the address range is invalid
        uint8_t exception_response[9] = {
            request[0], request[1],  // Transaction ID
            request[2], request[3],              // Protocol ID
            0x00, 0x03,              // Length (3 bytes: unit ID, function code, exception code)
            request[6],              // Unit ID
            request[7] | 0x80,       // Function code with error flag
            0x02                     // Exception code: Illegal Data Address
        };

        // Send the exception response
        modbus_send_response(tpcb, exception_response, sizeof(exception_response), TCP_WRITE_FLAG_COPY);
        //tcp_output(tpcb);
        return;
    }

    // Write the coil values to the coil array
    for (uint16_t i = 0; i < quantity; i++)
    {
        uint8_t byte_index = i / 8;           // Byte index in the data payload
        uint8_t bit_index = i % 8;           // Bit index within the byte
        uint8_t coil_state = (coil_values[byte_index] >> bit_index) & 0x01;

        // Update the corresponding coil
        modbus_coils[start_address + i] = coil_state;
    }

    // Prepare the response (acknowledgment)
    uint8_t response[12];
    response[0] = request[0];               // Transaction ID high byte
    response[1] = request[1];               // Transaction ID low byte
    response[2] = request[2];                     // Protocol ID high byte
    response[3] = request[3];                     // Protocol ID low byte
    response[4] = 0x00;                     // Length high byte
    response[5] = 0x06;                     // Length low byte (6 bytes follow Unit ID)
    response[6] = request[6];               // Unit ID
    response[7] = request[7];               // Function code
    response[8] = request[8];               // Starting address high byte
    response[9] = request[9];               // Starting address low byte
    response[10] = request[10];             // Quantity of coils high byte
    response[11] = request[11];             // Quantity of coils low byte

    // Send the response
    modbus_send_response(tpcb, response, sizeof(response), TCP_WRITE_FLAG_COPY);
   // tcp_output(tpcb);
}

void modbus_illegal_function_exception(struct tcp_pcb *tpcb, uint8_t unit_id, uint8_t function_code, uint16_t transaction_id)
{
    // Prepare the Modbus exception response
    uint8_t response[9];

    // Transaction ID (echoed back from request)
    response[0] = (transaction_id >> 8) & 0xFF;  // Transaction ID high byte
    response[1] = transaction_id & 0xFF;         // Transaction ID low byte

    // Protocol ID (always 0 for Modbus TCP)
    response[2] = 0x00;  // Protocol ID high byte
    response[3] = 0x00;  // Protocol ID low byte

    // Length (3 bytes for Unit ID, Function Code, and Exception Code)
    response[4] = 0x00;  // Length high byte
    response[5] = 0x03;  // Length low byte

    // Unit ID (as received in the request)
    response[6] = unit_id;

    // Function Code with Exception Flag (MSB set to 1 to indicate an error)
    response[7] = function_code | 0x80;

    // Exception Code (Illegal Function - 0x01)
    response[8] = 0x01;

    // Send the exception response
    modbus_send_response(tpcb, response, sizeof(response), TCP_WRITE_FLAG_COPY);
   // tcp_output(tpcb);
}



void modbus_send_response(struct tcp_pcb *pcb, void *arg, u16_t len, u8_t apiflags)
{
    struct tcp_pcb *tpcb = pcb;
    uint8_t *response = (uint8_t *)arg;
    uint16_t len_buf = len;

    // Check if there is enough space in the send buffer
    if (tcp_sndbuf(tpcb) >= len_buf) {
        tcp_write(tpcb, response, len_buf, TCP_WRITE_FLAG_COPY);
        tcp_output(tpcb);
    } else {
        // Handle buffer overflow (e.g., retry later or discard the response)
    }
}




