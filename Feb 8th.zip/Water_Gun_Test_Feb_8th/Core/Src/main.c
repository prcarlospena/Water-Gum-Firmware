/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "lwip.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <modbus_tcp_server.h>
#include "tuss4470.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BUZZER_ON()   HAL_GPIO_WritePin(BUZZER_OUT_GPIO_Port, BUZZER_OUT_Pin, GPIO_PIN_SET)
#define BUZZER_OFF()  HAL_GPIO_WritePin(BUZZER_OUT_GPIO_Port, BUZZER_OUT_Pin, GPIO_PIN_RESET)

#define VIB_ON()      HAL_GPIO_WritePin(VIBRATOR_OUT_GPIO_Port, VIBRATOR_OUT_Pin, GPIO_PIN_SET)
#define VIB_OFF()     HAL_GPIO_WritePin(VIBRATOR_OUT_GPIO_Port, VIBRATOR_OUT_Pin, GPIO_PIN_RESET)

#define RED_LED_ON()  HAL_GPIO_WritePin(RED_LED_OUT_GPIO_Port, RED_LED_OUT_Pin, GPIO_PIN_SET)
#define RED_LED_OFF() HAL_GPIO_WritePin(RED_LED_OUT_GPIO_Port, RED_LED_OUT_Pin, GPIO_PIN_RESET)

#define BLUE_LED_ON()  HAL_GPIO_WritePin(BLUE_LED_OUT_GPIO_Port, BLUE_LED_OUT_Pin, GPIO_PIN_SET)
#define BLUE_LED_OFF() HAL_GPIO_WritePin(BLUE_LED_OUT_GPIO_Port, BLUE_LED_OUT_Pin, GPIO_PIN_RESET)

#define ALERT_TOTAL_TIME_MS   1500
#define BUZZER_ON_TIME_MS     200
#define BUZZER_OFF_TIME_MS    200

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim8;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
volatile uint8_t burst_complete_flag = 0;
char command_line[CMD_BUFFER_SIZE];
extern char cmd_buffer[CMD_BUFFER_SIZE];
Command_t current_cmd;
extern uint16_t modbus_holding_registers[10];
extern uint8_t modbus_coils[10];
extern uint8_t modbus_inputs[10];
extern uint16_t modbus_input_registers[10];
extern struct netif gnetif;  // define this
#define ADC_NUM_CONVERSIONS 1
#define ADC_RAW_TO_VOLTAGE 0.000050535477f
__attribute__((section(".adcarray"))) uint16_t adcValue[10];
uint8_t MB_Trigger=0;
uint8_t MB_Levelok=0;
 uint32_t gpio_last_toggle_time = 0;
 uint8_t gpio_toggle_state = 0;
volatile uint8_t uart_rx_flag = 0;

uint8_t cmd_line_index = 0;
int count=0;

uint16_t adc[10000];
uint16_t ind = 0;
uint16_t ADC_VAL;
uint8_t do_read1 = 0;
uint8_t read_done =0;
volatile uint32_t tof_start_us = 0;
volatile uint32_t tof_stop_us  = 0;
volatile uint8_t  echo_received = 0;

uint8_t flag = 0;
uint8_t prev_flag = 0;

uint8_t alert_active = 0;
uint8_t buzzer_state = 0;

uint32_t alert_start_time = 0;
uint32_t buzzer_toggle_time = 0;

volatile uint32_t pulseCount = 0;
volatile uint32_t targetPulses = 0;
uint32_t burst_done = 0;
volatile uint8_t toggle_count = 0;
volatile uint8_t gpio_state = 0;  // 0 = LOW, 1 = HIGH

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM8_Init(void);
static void MX_TIM1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void StartBurst(uint32_t pulses)
{
    /* 1. Stop counter immediately */
    TIM1->CR1 &= ~TIM_CR1_CEN;

    /* 2. Force output HIGH while we reconfigure
          OC1M = 0b0101 = "Force Active" → pin stays HIGH */
    uint32_t ccmr1 = TIM1->CCMR1;
    ccmr1 &= ~TIM_CCMR1_OC1M_Msk;
    ccmr1 |= (5U << TIM_CCMR1_OC1M_Pos);   // Force Active
    TIM1->CCMR1 = ccmr1;

    /* Ensure channel + MOE are on so forced-HIGH actually drives the pin */
    TIM1->CCER |= TIM_CCER_CC1E;
    TIM1->BDTR |= TIM_BDTR_MOE;

    /* 3. Load repetition counter */
    TIM1->RCR = pulses - 1;

    /* 4. Reset counter, preload RCR into shadow register */
    TIM1->CNT  = 0;
    TIM1->EGR  = TIM_EGR_UG;
    __HAL_TIM_CLEAR_FLAG(&htim1, TIM_FLAG_UPDATE);

    /* 5. One-pulse mode — timer stops itself after RCR+1 overflows */
    TIM1->CR1 |= TIM_CR1_OPM;

    /* 6. Switch back to PWM1 (0b0110) — output is still HIGH
          because CNT=0 < CCR in PWM1 mode */
    ccmr1  = TIM1->CCMR1;
    ccmr1 &= ~TIM_CCMR1_OC1M_Msk;
    ccmr1 |= (6U << TIM_CCMR1_OC1M_Pos);   // PWM Mode 1
    TIM1->CCMR1 = ccmr1;

    /* 7. Enable update interrupt (fires after last pulse) */
    __HAL_TIM_ENABLE_IT(&htim1, TIM_IT_UPDATE);

    /* 8. Start — first edge will be HIGH→LOW at CNT=CCR (clean!) */
    TIM1->CR1 |= TIM_CR1_CEN;
}


/*void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM1)
    {
        __HAL_TIM_DISABLE_IT(&htim1, TIM_IT_UPDATE);
        TUSS4470_IO1_Set(1);

        // Force VDRV Hi-Z immediately after burst for clean listen
        TUSS4470_WriteRegister(VDRV_CTRL, 0x6F);  // DIS_VDRV_REG_LSTN=1, VDRV_HI_Z=1

        burst_complete_flag = 1;
    }
}*/

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM1)
    {
        __HAL_TIM_DISABLE_IT(&htim1, TIM_IT_UPDATE);
        TUSS4470_IO1_Set(1);
        burst_complete_flag = 1;
    }
}




//void TUSS4470_StartPWMBurst_175kHz(uint32_t pulses)
//{
//    pulseCount = 0;
//    targetPulses = pulses;
//    burst_done = 0;
//    toggle_count = 0;
//
//    // Ensure HIGH to start
//    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_RESET);
//    gpio_state = 0;
//
//    // Reset and start timer
//    __HAL_TIM_SET_COUNTER(&htim1, 0);
//    HAL_TIM_Base_Start_IT(&htim1);
//
//    printf("PWM Burst Started: %lu pulses at 175kHz\r\n", pulses);
//}
//
//void TUSS4470_StopPWM(void)
//{
//    HAL_TIM_Base_Stop_IT(&htim1);
//    __HAL_TIM_SET_COUNTER(&htim1, 0);
//
//    // Set HIGH
//    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_SET);
//    TUSS4470_IO1_Set(1);
//
//    burst_done = 1;
//    printf("PWM Stopped: %lu pulses completed\r\n", pulseCount);
//}
////void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
////{
////    if (htim->Instance == TIM1)
////    {
////        // Toggle GPIO
////        HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_9);
////        toggle_count++;
////
////        // 2 toggles = 1 complete pulse (HIGH→LOW→HIGH)
////        if (toggle_count % 2 == 0)
////        {
////            pulseCount++;
////
////            if (pulseCount >= targetPulses)
////            {
////                TUSS4470_StopPWM();
//////                TUSS4470_IO1_Set(1);
////            }
////        }
////    }
////}
//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
//{
//    if (htim->Instance == TIM1)
//    {
//        // Alternate between HIGH and LOW
//        if (gpio_state == 0)
//        {
//            // Set HIGH (start of pulse)
//            HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_SET);
//            gpio_state = 1;
//        }
//        else
//        {
//            // Set LOW (end of pulse)
//            HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_RESET);
//            gpio_state = 0;
//
//            // Count complete pulse after HIGH→LOW cycle
//            pulseCount++;
//
//            // Check if we've reached target
//            if (pulseCount >= targetPulses)
//            {
//                TUSS4470_StopPWM();
//                TUSS4470_IO1_Set(1);
//            }
//        }
// }
//}
//

//void PE9_To_GPIO_High(void)
//{
//    GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//    // Configure PE9 as output
//    GPIO_InitStruct.Pin = GPIO_PIN_9;
//    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//    GPIO_InitStruct.Pull = GPIO_NOPULL;
//    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
//    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
//
//    // Set HIGH
//    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_SET);
//}
//
//// Function to configure PE9 as TIM1_CH1 PWM
//void PE9_To_TIM1_PWM(void)
//{
//    GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//    // Configure PE9 as alternate function (TIM1_CH1)
//    GPIO_InitStruct.Pin = GPIO_PIN_9;
//    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//    GPIO_InitStruct.Pull = GPIO_NOPULL;
//    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
//    GPIO_InitStruct.Alternate = GPIO_AF1_TIM1;  // Check your datasheet for correct AF
//    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
//}
//
//// Start PWM burst with fixed number of pulses
//void TUSS4470_StartPWMBurst(uint32_t freq, uint32_t pulses)
//{
//    // Ensure pin is HIGH initially
//    PE9_To_GPIO_High();
//    HAL_Delay(1);
//
//    // Configure pin for PWM
//    PE9_To_TIM1_PWM();
//
//    // Reset counters
//    pulseCount = 0;
//    targetPulses = pulses;
//    burst_done = 0;
//
//    // Calculate timer parameters (for dynamic frequency)
//    uint32_t timerClock = 80000000; // 80 MHz
//    uint32_t arr = (timerClock / freq) - 1;
//
//    // Configure timer
//    __HAL_TIM_SET_AUTORELOAD(&htim1, arr);
//    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, arr / 2); // 50% duty cycle
//    __HAL_TIM_SET_COUNTER(&htim1, 0);
//
//    // Start PWM and interrupt
//    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
//    HAL_TIM_Base_Start_IT(&htim1);
//
//    printf("PWM Burst Started - Target Pulses: %lu at %lu Hz\r\n", pulses, freq);
//}

//// Start PWM burst with fixed 175kHz (optimized)
//void TUSS4470_StartPWMBurst_175kHz(uint32_t pulses)
//{
//	 TUSS4470_IO1_Set(0);
//    // Ensure pin is HIGH initially
//    PE9_To_GPIO_High();
//    HAL_Delay(1);
//
//    // Configure pin for PWM
//    PE9_To_TIM1_PWM();
//
//    // Reset counters
//    pulseCount = 0;
//    targetPulses = pulses;
//    burst_done = 0;
//
//    // Fixed 175kHz parameters (already set in CubeMX)
//    // ARR = 456, CCR = 228, actual freq = 175.05 kHz
//    __HAL_TIM_SET_COUNTER(&htim1, 0);
//
//    // Start PWM and interrupt
//    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
//    HAL_TIM_Base_Start_IT(&htim1);
//
//    printf("PWM Burst Started - Target Pulses: %lu at 175kHz\r\n", pulses);
//}
//void TUSS4470_StartPWMBurst_175kHz(uint32_t pulses)
//{
//	 TUSS4470_IO1_Set(0);
//    PE9_To_GPIO_High();
//    HAL_Delay(1);
//    PE9_To_TIM1_PWM();
//
//    pulseCount = 0;
//    targetPulses = pulses;
//    burst_done = 0;
//
//    // Get actual timer clock dynamically
//    uint32_t pclk2 = HAL_RCC_GetPCLK2Freq();
//
//    RCC_ClkInitTypeDef clkConfig;
//    uint32_t flashLatency;
//    HAL_RCC_GetClockConfig(&clkConfig, &flashLatency);
//
//    uint32_t timerClock;
//    if (clkConfig.APB2CLKDivider == RCC_HCLK_DIV1)
//    {
//        timerClock = pclk2;
//    }
//    else
//    {
//        timerClock = pclk2 * 2;  // Timer clock = PCLK2 × 2 when prescaler != 1
//    }
//
//    uint32_t targetFreq = 175000; // 175 kHz
//    uint32_t arr = (timerClock / targetFreq) - 1;
//
//    printf("Timer Clock: %lu Hz\r\n", timerClock);
//    printf("ARR: %lu\r\n", arr);
//    printf("Actual Freq: %lu Hz\r\n", timerClock / (arr + 1));
//
//    __HAL_TIM_SET_AUTORELOAD(&htim1, arr);
//    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, arr / 2);
//    __HAL_TIM_SET_COUNTER(&htim1, 0);
//
//    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
//    HAL_TIM_Base_Start_IT(&htim1);
//}
//// Timer Update Interrupt Callback
//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
//{
//    if (htim->Instance == TIM1)
//    {
//        pulseCount++;
//
//        if (pulseCount >= targetPulses)
//        {
//            // Stop PWM and timer
//            HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
//            HAL_TIM_Base_Stop_IT(&htim1);
//
//            // Set pin to HIGH (idle state)
//            PE9_To_GPIO_High();
//
//            burst_done = 1;
//
//            printf("BURST DONE - Total Pulses: %lu\r\n", pulseCount);
//            TUSS4470_IO1_Set(1);
//        }
//    }
//}

//static void PE9_To_TIM1_PWM(void)
//{
//    GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//    __HAL_RCC_GPIOE_CLK_ENABLE();
//
//    GPIO_InitStruct.Pin = GPIO_PIN_9;
//    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
//    GPIO_InitStruct.Pull = GPIO_NOPULL;
//    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
//    GPIO_InitStruct.Alternate = GPIO_AF1_TIM1;   // TIM1_CH1
//    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
//
//}
//static void PE9_To_GPIO_High(void)
//{
//	 TUSS4470_IO1_Set(1);
//    GPIO_InitTypeDef GPIO_InitStruct = {0};
//
//    __HAL_RCC_GPIOE_CLK_ENABLE();
//
//    GPIO_InitStruct.Pin = GPIO_PIN_9;
//    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
//    GPIO_InitStruct.Pull = GPIO_NOPULL;
//    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
//    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
//
//    HAL_GPIO_WritePin(GPIOE, GPIO_PIN_9, GPIO_PIN_SET);
//
//}

//void TUSS4470_StartPWMBurst(uint32_t freq, uint32_t pulses)
//{
//	   TUSS4470_IO1_Set(0);
//	PE9_To_TIM1_PWM();
//    pulseCount = 0;
//    targetPulses = pulses;
//
//    uint32_t timerClock = HAL_RCC_GetPCLK2Freq() * 2; // TIM1 clock
//    uint32_t arr = (timerClock / freq) - 1;
//
//    __HAL_TIM_SET_AUTORELOAD(&htim1, arr);
//    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, arr / 2);
//
//    __HAL_TIM_SET_COUNTER(&htim1, 0);
//    HAL_TIM_Base_Start_IT(&htim1);
//    HAL_TIM_PWM_Start_IT(&htim1, TIM_CHANNEL_1);
//
//
//    printf("Pulse Count: %lu \r\n",pulseCount);
//}
//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
//{
//    if (htim->Instance == TIM1)
//    {
//
//
//        if (pulseCount >= targetPulses)
//        {
//        	 HAL_TIM_Base_Stop_IT(&htim1);
//            HAL_TIM_PWM_Stop_IT(&htim1, TIM_CHANNEL_1);
//            __HAL_TIM_DISABLE(&htim1);
//             PE9_To_GPIO_High();
//            burst_done=1;
//            pulseCount=0;
//            //
//
//
//            return ;
//
//        }
//        pulseCount++;
//        printf("Pulse Count: %lu \r\n",pulseCount);
//        HAL_TIM_Base_Start_IT(&htim1);
//
//
//    }
//}
//void TUSS4470_StartPWMBurst(uint32_t freq, uint32_t pulses)
//{
//    PE9_To_GPIO_High();
//    HAL_Delay(1);
//    PE9_To_TIM1_PWM();
//
//    pulseCount = 0;
//    targetPulses = (pulses+2);
//
//    uint32_t timerClock = 80000000; // 80 MHz
//    uint32_t arr = (timerClock / freq) - 1;
//
//    // For 175kHz with 80MHz clock: arr = 456, actual freq = 175.05kHz
//
//    __HAL_TIM_SET_AUTORELOAD(&htim1, arr);
//    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, arr / 2);
//
//    __HAL_TIM_SET_COUNTER(&htim1, 0);
//    TUSS4470_IO1_Set(0);
//    HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
//    HAL_TIM_Base_Start_IT(&htim1);
//}
//
//void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
//{
//    if (htim->Instance == TIM1)
//    {
//        pulseCount++;
//        printf("Pulse Count: %lu \r\n", pulseCount);
//
//        if (pulseCount >= targetPulses)
//        {
//            // Stop PWM and timer
//            HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_1);
//            HAL_TIM_Base_Stop_IT(&htim1);
//
//            // Set pin to HIGH (idle state)
//            PE9_To_GPIO_High();
//
//            burst_done = 1;
//
//            printf("BURST DONE - Total Pulses: %lu \r\n", pulseCount);
//            TUSS4470_IO1_Set(1);
//        }
//    }
//}

uint32_t micros(void)
{
    return DWT->CYCCNT / (HAL_RCC_GetHCLKFreq() / 1000000U);
}

volatile uint32_t rise_time = 0;
volatile uint32_t fall_time = 0;
volatile uint32_t pulse_width_us = 0;
volatile uint8_t measurement_done = 0;
static uint32_t measurement_start_tick = 0;
static uint8_t measurement_in_progress = 0;

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_7)   // PE7
    {
        if (HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_7) == GPIO_PIN_SET)
        {
            // 🔺 Rising edge → start timing
            rise_time = micros();
        }
        else
        {
            // 🔻 Falling edge → stop timing
            fall_time = micros();

            if (fall_time >= rise_time)
                pulse_width_us = fall_time - rise_time;
            else
                pulse_width_us = (0xFFFFFFFF - rise_time) + fall_time + 1;

            measurement_done = 1;
        }
    }
}


//void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
//{
//	if(do_read1 == 1)
//	{
//		adc[ind]=adcValue[0];
//		ind++;
//		if(ind >= 9999)
//		{
//			ind=0;
//			do_read1 = 0;
//			read_done = 1;
//		}
//	}
//}

uint8_t NonBlockingDelay(uint32_t *prevTick, uint32_t delayMs)
{
    if (HAL_GetTick() - *prevTick >= delayMs)
    {
        *prevTick = HAL_GetTick();
        return 1;   // delay completed
    }
    return 0;       // still waiting
}
// UART1 Receive Callback
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if(huart->Instance == USART1) {
        uart_rx_flag = 1;
    }
}

// Redirect printf to UART1 (for TUSS4470_UART_Send)
#ifdef __GNUC__
int _write(int file, char *ptr, int len) {
    HAL_UART_Transmit(&huart1, (uint8_t*)ptr, len, HAL_MAX_DELAY);
    return len;
}
#endif

void Alert_Handler(void)
{
    uint32_t now = HAL_GetTick();

    /* Detect rising edge: flag 0 -> 1 */
    if ((modbus_coils[1] == 1) && (prev_flag == 0))
    {
        alert_active = 1;
        alert_start_time = now;

        buzzer_state = 1;
        buzzer_toggle_time = now;

        BUZZER_ON();
        VIB_ON();
        RED_LED_ON();

    }

    if (alert_active)
    {
        /* Handle buzzer beep-beep */
        if (buzzer_state)
        {
            if (now - buzzer_toggle_time >= BUZZER_ON_TIME_MS)
            {
                BUZZER_OFF();
                buzzer_state = 0;
                buzzer_toggle_time = now;
            }
        }
        else
        {
            if (now - buzzer_toggle_time >= BUZZER_OFF_TIME_MS)
            {
                BUZZER_ON();
                buzzer_state = 1;
                buzzer_toggle_time = now;
            }
        }

        /* Stop everything after total duration */
        if (now - alert_start_time >= ALERT_TOTAL_TIME_MS)
        {
            BUZZER_OFF();
            VIB_OFF();
            RED_LED_OFF();
            BLUE_LED_OFF();

            alert_active = 0;
        }
    }

    prev_flag = modbus_coils[1];
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	 SCB->CCR &= ~SCB_CCR_UNALIGN_TRP_Msk;
  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* Enable the CPU Cache */

  /* Enable I-Cache---------------------------------------------------------*/
  SCB_EnableICache();

  /* Enable D-Cache---------------------------------------------------------*/
  SCB_EnableDCache();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_SPI1_Init();
  MX_USART1_UART_Init();
  MX_LWIP_Init();
  MX_TIM8_Init();
  MX_TIM1_Init();
  /* USER CODE BEGIN 2 */
 // HAL_Delay(1000);
//  HAL_ADCEx_Calibration_Start(&hadc1, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED);
//  HAL_ADC_Start_DMA(&hadc1, (uint32_t *) adcValue, 10);
  HAL_TIM_Base_Start(&htim8);
  modbus_tcp_init();


  // Test UART1 communication
  char test_message[] = "UART1 Test: STM32H7 UART1 is working!\r\n";
  HAL_UART_Transmit(&huart1, (uint8_t*)test_message, strlen(test_message), HAL_MAX_DELAY);

  // Also test with printf
  printf("STM32H743 UART1 Initialized at 115200 baud\r\n");
  printf("System Clock: %lu Hz\r\n", HAL_RCC_GetHCLKFreq());
  printf("APB2 Clock (UART1): %lu Hz\r\n", HAL_RCC_GetPCLK2Freq());
  // Start UART1 receive in interrupt mode
   HAL_UART_Receive_IT(&huart1, (uint8_t*)cmd_buffer, 1);
 // PE9_To_GPIO_High();
  TUSS4470_IO1_Set(1);
   // Initialize TUSS4470 (same initialization as ESP32)
   TUSS4470_Init();
   uint32_t sum = 0;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	 // while (1)
	  //{
	      // Heartbeat: proves the MCU is running without ST-LINK
	  //    static uint32_t hb = 0;
	  //    if (HAL_GetTick() - hb >= 500)
	 //     {
	  //       hb = HAL_GetTick();
	  //        HAL_GPIO_TogglePin(GPIOD, BLUE_LED_OUT_Pin);
	 //     }
	 // }

	  MX_LWIP_Process();
 if(HAL_GPIO_ReadPin(TRIGGER_IN_GPIO_Port, TRIGGER_IN_Pin) == 0)
 {
	 BLUE_LED_ON();
	 continuousBurstEnabled=1;
	 modbus_coils[0] = 1;

 }
 else
 {
		BLUE_LED_OFF();
		 modbus_coils[0] = 0;


	 continuousBurstEnabled=0;

 }

	  Alert_Handler();


//	    for (uint8_t i = 0; i < 10; i++)
//	    {
//	        sum += adcValue[i];
//	    }
////	    TUSS4470_UART_Send("%ld \r\n", adcValue[1]);
//
//	    modbus_holding_registers[0] = sum / 10.0f;
//	    modbus_holding_registers[1] = modbus_holding_registers[0]  * ADC_RAW_TO_VOLTAGE * 1000;


     	  if(uart_rx_flag)// || HAL_GPIO_ReadPin(TRIGGER_IN_GPIO_Port, TRIGGER_IN_Pin) == GPIO_PIN_SET)
    	  	    {
    	  	        uart_rx_flag = 0;

    	  	        char received_char = cmd_buffer[0];

    	  	        // Process based on received character
    	  	        if(received_char == '\r' || received_char == '\n') {
    	  	            // Echo newline to terminal
    	  	            TUSS4470_UART_Send("\r\n");

    	  	            // End of command
    	  	            if(cmd_line_index > 0) {
    	  	                command_line[cmd_line_index] = '\0';

    	  	                // Parse and process command
    	  	                Command_t cmd;
    	  	                TUSS4470_ParseCommand(command_line, &cmd);
    	  	                TUSS4470_ProcessCommand(&cmd);

    	  	                // Reset command buffer
    	  	                cmd_line_index = 0;
    	  	            }

    	  	            // Ensure UART is ready for next reception
    	  	            __HAL_UART_FLUSH_DRREGISTER(&huart1);
    	  	            __HAL_UART_CLEAR_FLAG(&huart1, UART_FLAG_ORE);
    	  	        }
    	  	        else if(received_char == '\b' || received_char == 0x7F) {
    	  	            // Backspace
    	  	            if(cmd_line_index > 0) {
    	  	                cmd_line_index--;
    	  	                TUSS4470_UART_Send("\b \b");  // Erase character
    	  	            }
    	  	        }
    	  	        else if(cmd_line_index < CMD_BUFFER_SIZE - 1) {
    	  	            // Add character to buffer and echo
    	  	            command_line[cmd_line_index++] = received_char;
    	  	            TUSS4470_UART_Send("%c", received_char);
    	  	        }

    	  	        // Clear any pending flags before restarting receive
    	  	        __HAL_UART_CLEAR_FLAG(&huart1, UART_FLAG_RXNE);

    	  	        // Restart UART receive with interrupt
    	  	        HAL_UART_Receive_IT(&huart1, (uint8_t*)cmd_buffer, 1);
    	  	    }


    	 if (burst_complete_flag)
    	      {
    	          burst_complete_flag = 0;
    	          TUSS4470_WriteRegister(TOF_CONFIG, 0x00);
    	          TUSS4470_WriteRegister(VDRV_CTRL, 0x6F);     // VDRV Hi-Z, charger fully off
    	      }

    if(continuousBurstEnabled)
    {
    	  MX_LWIP_Process();
      	if(measurement_done == 1 )
      	{
      		modbus_holding_registers[0]=pulse_width_us;
//      		TUSS4470_UART_Send("ECHO_DTECTED:TOF: %d",pulse_width_us);

      		measurement_done=0;
      	}
	                TUSS4470_ContinuousMode();
	                continuousBurstEnabled=0;
	}

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_DIV1;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = 2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_3;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOMEDIUM;
  RCC_OscInitStruct.PLL.PLLFRACN = 4096;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_16BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 0x0;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  hspi1.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi1.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi1.Init.TxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.RxCRCInitializationPattern = SPI_CRC_INITIALIZATION_ALL_ZERO_PATTERN;
  hspi1.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi1.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi1.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi1.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi1.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 479;   //479 = 175KHz , 699 = 120KHz Also change
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 240; //240 = 175KHz, 350 = 120KHz
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_SET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_ENABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM8 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM8_Init(void)
{

  /* USER CODE BEGIN TIM8_Init 0 */

  /* USER CODE END TIM8_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM8_Init 1 */

  /* USER CODE END TIM8_Init 1 */
  htim8.Instance = TIM8;
  htim8.Init.Prescaler = 23;
  htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim8.Init.Period = 10;
  htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim8.Init.RepetitionCounter = 0;
  htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim8) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM8_Init 2 */

  /* USER CODE END TIM8_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, BUZZER_OUT_Pin|VIBRATOR_OUT_Pin|TUSS_IO1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LED_CONTROL_OUT_Pin|TUSS_NCS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, BLUE_LED_OUT_Pin|GREEN_LED_OUT_Pin|RED_LED_OUT_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : BUZZER_OUT_Pin VIBRATOR_OUT_Pin TUSS_IO1_Pin */
  GPIO_InitStruct.Pin = BUZZER_OUT_Pin|VIBRATOR_OUT_Pin|TUSS_IO1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : TUSS_OUT3_Pin */
  GPIO_InitStruct.Pin = TUSS_OUT3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(TUSS_OUT3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LED_CONTROL_OUT_Pin */
  GPIO_InitStruct.Pin = LED_CONTROL_OUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_CONTROL_OUT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : TUSS_NCS_Pin */
  GPIO_InitStruct.Pin = TUSS_NCS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(TUSS_NCS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : TUSS_OUT4_Pin */
  GPIO_InitStruct.Pin = TUSS_OUT4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(TUSS_OUT4_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : BLUE_LED_OUT_Pin GREEN_LED_OUT_Pin RED_LED_OUT_Pin */
  GPIO_InitStruct.Pin = BLUE_LED_OUT_Pin|GREEN_LED_OUT_Pin|RED_LED_OUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : TRIGGER_IN_Pin COMM_IN_Pin */
  GPIO_InitStruct.Pin = TRIGGER_IN_Pin|COMM_IN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*AnalogSwitch Config */
  HAL_SYSCFG_AnalogSwitchConfig(SYSCFG_SWITCH_PA0, SYSCFG_SWITCH_PA0_CLOSE);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(TUSS_OUT4_EXTI_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TUSS_OUT4_EXTI_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
//  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Configure PB1 as Analog Input */
  // 1. Enable Clock Access to GPIOB (if not already done by CubeMX)
  // __HAL_RCC_GPIOB_CLK_ENABLE();

  // 2. Configure Pin PB1
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG; // <--- MUST be Analog Mode
  GPIO_InitStruct.Pull = GPIO_NOPULL;      // <--- MUST be No Pull
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x38000000;
  MPU_InitStruct.Size = MPU_REGION_SIZE_32KB;
  MPU_InitStruct.SubRegionDisable = 0x00;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_NOT_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Number = MPU_REGION_NUMBER1;
  MPU_InitStruct.BaseAddress = 0x30000000;
  MPU_InitStruct.SubRegionDisable = 0x0;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL1;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
